# v49_binance_realtime_ws.py
# 🚀《我要飞合约版》v49 实时订阅模块
# 功能：实时订阅 BTC/ETH/SOL USDT 对行情数据（币安现货）
# 环境：Python 3.9+，需安装 websockets 与 asyncio 库
# 作者：JACK 项目专用版

import asyncio
import json
import websockets
from datetime import datetime

# 币安 WebSocket 实时行情接口（现货）
BINANCE_WS_URL = "wss://stream.binance.com:9443/stream?streams=btcusdt@ticker/ethusdt@ticker/solusdt@ticker"

# 输出函数：带北京时间
def log(msg):
    beijing_time = datetime.utcnow().timestamp() + 8 * 3600
    ts = datetime.fromtimestamp(beijing_time).strftime("[%Y-%m-%d %H:%M:%S 北京时间]")
    print(f"{ts} {msg}")

# 主异步函数
async def main():
    log("🚀 启动《我要飞合约版》v49 实时订阅模块")
    log("系统正在连接币安实时行情接口，请稍候...")
    
    try:
        async with websockets.connect(BINANCE_WS_URL, ping_interval=20, ping_timeout=10) as ws:
            log("✅ 已连接币安实时数据流，开始接收行情...")
            last_price = {"BTCUSDT": 0, "ETHUSDT": 0, "SOLUSDT": 0}
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                stream = data.get("stream", "")
                info = data.get("data", {})
                symbol = info.get("s", "")
                price = float(info.get("c", 0.0))
                percent = float(info.get("P", 0.0))

                if symbol:
                    # 计算价格变化
                    old_price = last_price[symbol]
                    if old_price != 0:
                        diff = price - old_price
                        direction = "📈上涨" if diff > 0 else "📉下跌" if diff < 0 else "→持平"
                        log(f"{symbol} | 当前价: {price:.2f} USDT | 涨跌: {percent:.2f}% | 状态: {direction}")
                    last_price[symbol] = price
    except Exception as e:
        log(f"❌ 连接中断：{e}")
        log("⚠️ 系统将在 5 秒后自动重连...")
        await asyncio.sleep(5)
        await main()

# 启动事件循环
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log("🛑 手动终止订阅，系统已退出。")