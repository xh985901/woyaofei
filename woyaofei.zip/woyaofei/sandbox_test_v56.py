# 🚀《我要飞合约版》v56 多币情绪共振引擎 + 跨币热度联动系统
# -*- coding: utf-8 -*-
import requests, time, random
from datetime import datetime
from collections import deque

api_url = "https://api.binance.com/api/v3/ticker/price"
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

采样间隔 = 8
记忆长度 = 10

价格记忆 = {s: deque(maxlen=记忆长度) for s in symbols}
情绪缓存 = {s: 0.0 for s in symbols}
方向缓存 = {s: 0 for s in symbols}

def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        r = requests.get(api_url, params={"symbol": symbol}, timeout=5)
        return float(r.json()["price"])
    except:
        return None

def 波动计算(prices):
    if len(prices) < 2: return 0
    return (prices[-1] - prices[-2]) / prices[-2] * 100

def 计算情绪(symbol, prices):
    if len(prices) < 3: return "冷静", 0.0
    seq = [(prices[i] - prices[i - 1]) / prices[i - 1] * 100 for i in range(1, len(prices))]
    活跃度 = sum(abs(x) for x in seq[-5:]) / 5
    连续方向 = sum(1 if x > 0 else -1 for x in seq[-5:])
    热度 = 活跃度 + abs(连续方向) * 0.2

    if 热度 < 0.3: 状态 = "冷静"
    elif 热度 < 0.8: 状态 = "观望"
    elif 热度 < 1.5: 状态 = "活跃"
    else: 状态 = "过热"

    方向缓存[symbol] = 1 if 连续方向 > 0 else -1
    情绪缓存[symbol] = 热度
    return 状态, 热度, 连续方向

def 计算共振():
    pairs = [("BTCUSDT", "ETHUSDT"), ("BTCUSDT", "SOLUSDT"), ("ETHUSDT", "SOLUSDT")]
    共振得分 = 0
    for a, b in pairs:
        if abs(情绪缓存[a] - 情绪缓存[b]) < 0.3 and 方向缓存[a] == 方向缓存[b]:
            共振得分 += 1
    return 共振得分 / len(pairs)  # 输出0~1之间

def 生成信号(symbol, 当前价, 状态, 热度, 连续方向, 共振系数):
    基础预测 = 连续方向 * 热度
    把握度 = min(100, abs(基础预测) * (80 + 共振系数 * 30))
    风险 = "高" if abs(基础预测) > 2 else "中" if abs(基础预测) > 1 else "低"
    稳定度 = max(70, 100 - 热度 * 15)
    信心 = 90 + 共振系数 * 10

    if 把握度 < 40: 建议 = "观望"
    elif 连续方向 > 0: 建议 = "轻仓多"
    elif 连续方向 < 0: 建议 = "轻仓空"
    else: 建议 = "观望"

    止盈 = 当前价 * (1.006 if 连续方向 > 0 else 0.994)
    止损 = 当前价 * (0.992 if 连续方向 > 0 else 1.008)
    return 把握度, 风险, 稳定度, 信心, 建议, 基础预测, 止盈, 止损

print(f"{获取时间()} 🚀 启动《我要飞合约版》v56 多币情绪共振引擎 + 跨币热度联动系统\n")

while True:
    print("="*75)
    for s in symbols:
        当前价 = 获取币价(s)
        if not 当前价:
            print(f"⚠️ {s} 数据获取失败，跳过。")
            continue

        价格记忆[s].append(当前价)
        if len(价格记忆[s]) < 3:
            continue

        状态, 热度, 连续方向 = 计算情绪(s, 价格记忆[s])

    共振系数 = 计算共振()

    print(f"🤝 当前多币共振指数：{共振系数*100:.1f}%")
    for s in symbols:
        if len(价格记忆[s]) < 3: continue
        当前价 = 价格记忆[s][-1]
        状态, 热度, 连续方向 = 计算情绪(s, 价格记忆[s])
        把握度, 风险, 稳定度, 信心, 建议, 基础预测, 止盈, 止损 = 生成信号(s, 当前价, 状态, 热度, 连续方向, 共振系数)

        print(f"{获取时间()} {s} 当前价：{当前价:.2f} USDT | 情绪：{状态} ({热度:.2f})")
        print(f"➡ 建议：{建议} | 把握度：{把握度:.1f}% | 风险：{风险} | 稳定度：{稳定度:.1f}% | 信心：{信心:.1f}%")
        print(f"📊 共振修正预测：{基础预测:.3f} | 止盈：{止盈:.2f} | 止损：{止损:.2f}")
        print("-"*75)

    print("系统稳定运行中，AI多币共振分析持续监控...\n")
    time.sleep(采样间隔)