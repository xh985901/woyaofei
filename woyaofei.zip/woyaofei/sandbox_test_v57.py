# 🚨《我要飞合约版》v57 AI风险分级雷达 + 仓位自动调节系统
# -*- coding: utf-8 -*-
import requests, time, random
from datetime import datetime

api_url = "https://api.binance.com/api/v3/ticker/price"
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        r = requests.get(api_url, params={"symbol": symbol}, timeout=5)
        return float(r.json()["price"])
    except:
        return None

def 风险评估(波动, 情绪热度, 共振):
    """三因素合并计算风险指数"""
    风险得分 = (波动 * 0.5 + 情绪热度 * 0.3 + (1 - 共振) * 0.2) * 100
    if 风险得分 < 30: 等级, 建议 = "低", "可轻仓操作（≤30%）"
    elif 风险得分 < 60: 等级, 建议 = "中", "谨慎仓位（≤15%）"
    else: 等级, 建议 = "高", "暂停入场，风险过高"
    return 风险得分, 等级, 建议

def 获取模拟数据():
    """模拟AI输出（真实环境替换为v56输出值）"""
    波动 = round(random.uniform(0.5, 2.5), 2)
    情绪热度 = round(random.uniform(0.3, 1.8), 2)
    共振 = round(random.uniform(0.6, 1.0), 2)
    return 波动, 情绪热度, 共振

def 风控评分(风险等级列表):
    映射 = {"低": 90, "中": 60, "高": 30}
    平均分 = sum(映射[r] for r in 风险等级列表) / len(风险等级列表)
    return 平均分

print(f"{获取时间()} 🚀 启动《我要飞合约版》v57 AI风险分级雷达 + 仓位自动调节系统\n")

while True:
    风险结果 = []
    print("="*80)
    for s in symbols:
        当前价 = 获取币价(s)
        if not 当前价:
            print(f"⚠️ {s} 数据未返回，跳过。")
            continue

        波动, 情绪热度, 共振 = 获取模拟数据()
        风险得分, 等级, 建议 = 风险评估(波动, 情绪热度, 共振)
        风险结果.append(等级)

        print(f"{获取时间()} {s} 当前价：{当前价:.2f} USDT")
        print(f"📊 波动：{波动:.2f} | 情绪热度：{情绪热度:.2f} | 共振指数：{共振*100:.1f}%")
        print(f"⚠️ 风险指数：{风险得分:.1f} | 等级：{等级} | 建议仓位：{建议}")
        print("-"*80)

    综合评分 = 风控评分(风险结果)
    print(f"🧠 系统综合风险得分：{综合评分:.1f}/100")
    if 综合评分 > 80:
        状态 = "安全运行 ✅"
    elif 综合评分 > 50:
        状态 = "需谨慎 ⚠️"
    else:
        状态 = "高风险 🚨 暂停入场"

    print(f"🧩 当前风险状态：{状态}")
    print("系统稳定运行中，AI风控雷达持续监测...\n")
    time.sleep(10)