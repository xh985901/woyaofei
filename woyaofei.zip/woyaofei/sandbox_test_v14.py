# -*- coding: utf-8 -*-
"""
🚀 《我要飞合约版》 v14
币安实时行情接入引擎（只读版 · 安全模式）
作者：JACK & ChatGPT
"""

import time
import random
import requests
from datetime import datetime

SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

class BinanceLiveFeed:
    def __init__(self):
        self.base_url = "https://api.binance.com/api/v3/ticker/24hr"

    def get_price(self, symbol):
        """获取币安实时价格与成交量"""
        try:
            res = requests.get(self.base_url, params={"symbol": symbol}, timeout=5)
            data = res.json()

            if isinstance(data, dict) and "lastPrice" in data:
                price = float(data["lastPrice"])
                volume = float(data.get("volume", 0))
                return price, volume
            else:
                print(f"[⚠️] 数据结构异常：{data}")
                return None, None

        except Exception as e:
            print(f"[❌] 请求错误：{e}")
            return None, None

    def run(self, loops=10):
        """循环抓取行情"""
        print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 🚀 启动币安实时行情引擎（v14）")
        for i in range(loops):
            print(f"\n第 {i+1}/{loops} 轮实时行情检测……")

            for sym in SYMBOLS:
                price, vol = self.get_price(sym)
                now = datetime.now().strftime("%H:%M:%S")

                if price:
                    print(f"[{now}] 📊 {sym} 现价: {price:.2f} USDT | 量: {vol:.2f}")
                else:
                    print(f"[{now}] ⚠️ 无法获取 {sym} 数据。")

                time.sleep(random.uniform(0.8, 1.2))  # 防封IP

        print(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] ✅ 币安实时行情采集结束。")

if __name__ == "__main__":
    feed = BinanceLiveFeed()
    feed.run(loops=5)