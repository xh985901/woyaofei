# ===========================================
sandbox_test_v115.py
# ===========================================

import os
import json
import datetime
from pathlib import Path

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")  # ✅ 使用无界面后端，防止 Android 报错
import matplotlib.pyplot as plt

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager
from mywoyaofei.modules.step_tpsl_real import StepTPSL


class BacktestEngine:
    """
    实盘回测引擎：
      - 读取历史 CSV 数据（需包含 close 列）
      - 根据规则执行模拟交易（涨买跌卖）
      - 调用 StepTPSL 执行止盈止损
      - 输出结果统计与收益图表（无界面保存）
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("BacktestEngine")
        self.tp_sl = StepTPSL()

        # 路径自动适配
        self.data_dir = Path(self.cfg.get("data_dir"))
        self.result_dir = Path(self.cfg.get("report_dir")) / "backtest_results"
        self.result_dir.mkdir(parents=True, exist_ok=True)

        self.logger.info("BacktestEngine 初始化完成", {
            "data_dir": str(self.data_dir),
            "result_dir": str(self.result_dir)
        })

    # ---------- 数据加载 ----------
    def load_csv(self, filename: str) -> pd.DataFrame:
        """加载历史数据 CSV"""
        path = self.data_dir / filename
        if not path.exists():
            self.logger.error(f"❌ 找不到数据文件: {path}")
            return None

        try:
            df = pd.read_csv(path)
        except Exception as e:
            self.logger.error(f"CSV 文件读取失败: {e}")
            return None

        if "close" not in df.columns:
            self.logger.error("CSV 缺少 'close' 列")
            return None

        self.logger.info(f"✅ 已加载历史数据: {filename}，共 {len(df)} 条记录")
        return df

    # ---------- 模拟执行 ----------
    def simulate(self, df: pd.DataFrame, entry_price_col="close"):
        """根据价格变化模拟买卖 + 止盈止损"""
        entry_price = None
        results = []

        for i in range(1, len(df)):
            current = float(df[entry_price_col].iloc[i])
            prev = float(df[entry_price_col].iloc[i - 1])

            # 简单规则：价格上升买入，下跌卖出
            if current > prev * 1.002:
                entry_price = prev
                self.logger.info(f"📈 模拟开多: {entry_price:.2f}")
            elif current < prev * 0.998:
                entry_price = prev
                self.logger.info(f"📉 模拟开空: {entry_price:.2f}")

            if entry_price:
                rec = self.tp_sl.evaluate_position(entry_price, current)
                if rec:
                    results.append(rec)
                    entry_price = None  # 平仓
        return results

    # ---------- 结果报告 ----------
    def report(self, results: list):
        """生成统计报告与收益曲线"""
        if not results:
            self.logger.warning("⚠️ 无交易记录可分析")
            return

        df = pd.DataFrame(results)
        df["pnl"] = df["profit_ratio"] * 100
        win_rate = (df["pnl"] > 0).sum() / len(df)
        max_drawdown = df["pnl"].min()
        avg_pnl = df["pnl"].mean()

        # 保存统计文件
        summary = {
            "records": len(df),
            "win_rate": round(win_rate * 100, 2),
            "max_drawdown": round(max_drawdown, 2),
            "avg_pnl": round(avg_pnl, 2)
        }
        save_path = self.result_dir / "backtest_summary.json"
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        self.logger.info(f"📊 回测结果统计：{summary}")

        # 绘制收益曲线（无界面模式）
        try:
            plt.figure(figsize=(8, 4))
            plt.plot(df["pnl"].cumsum(), color="blue", label="累计收益 (%)")
            plt.title("实盘回测 - 收益曲线")
            plt.xlabel("交易次数")
            plt.ylabel("累计收益 (%)")
            plt.grid(True)
            plt.legend()
            chart_path = self.result_dir / "equity_curve.png"
            plt.savefig(chart_path, dpi=150)
            plt.close()
            self.logger.info(f"✅ 收益曲线已生成: {chart_path}")
        except Exception as e:
            self.logger.warning(f"图表生成失败: {e}")

# ---------- 独立运行 ----------
if __name__ == "__main__":
    bt = BacktestEngine()
    df = bt.load_csv("sample_kline.csv")
    if df is not None:
        results = bt.simulate(df)
        bt.report(results)