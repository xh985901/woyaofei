# ───────────────────────────────
# 《我要飞合约版》源码 · 第1批
# 主入口 + 核心逻辑 + 公共工具

# ===== main.py =====
import sys
import os

# ✅ 关键：把 core 文件夹加入搜索路径
sys.path.append(os.path.join(os.path.dirname(__file__), 'core'))

# ✅ 从 mypythonapp.core 导入核心模块（不能省 mypythonapp）
from mypythonapp.core.engine import TradingEngine
from mypythonapp.core.scheduler import Scheduler
from mypythonapp.core.router import Router

print("TradingEngine 模块加载中（真实模式）")

def main():
    print("🚀 我要飞合约版 启动中...")

    engine = TradingEngine()
    scheduler = Scheduler(engine)
    router = Router(engine)

    engine.start()
    scheduler.run()
    router.route_tasks()

    print("✅ 系统框架启动完成（第1批）")

if __name__ == "__main__":
    main()


# ===== core/engine.py =====
class TradingEngine:
    """
    核心交易引擎：负责策略调用、数据流转、信号处理。
    """
    def __init__(self):
        self.status = "initialized"

    def execute(self):
        """执行主策略（占位）"""
        pass

    def stop(self):
        """停止所有运行模块"""
        self.status = "stopped"


# ===== core/scheduler.py =====
class Scheduler:
    """
    调度器：控制任务定时执行。
    """
    def __init__(self, engine):
        self.engine = engine

    def run(self):
        """主调度循环（占位）"""
        print("🕒 调度器运行中...")


# ===== core/router.py =====
class Router:
    """
    路由器：决定调用哪个模块。
    """
    def __init__(self, engine):
        self.engine = engine

    def route_tasks(self):
        """模块分发逻辑（占位）"""
        print("📡 路由初始化完成。")


# ===== utils/helpers.py =====
import time, logging

def now_ts():
    """返回当前时间戳（毫秒）"""
    return int(time.time() * 1000)

def log(msg):
    """统一日志输出"""
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print(f"[{ts}] {msg}")
    logging.info(msg)


# ===== utils/indicators.py =====
def calc_ma(data, period=15):
    """计算简单均线"""
    if len(data) < period:
        return None
    return sum(data[-period:]) / period

def calc_volatility(data):
    """计算波动率（标准差占位）"""
    if len(data) < 2:
        return 0
    mean = sum(data)/len(data)
    return (sum((x - mean)**2 for x in data)/len(data))**0.5


# ===== utils/validators.py =====
def is_valid_symbol(symbol: str) -> bool:
    """校验交易对是否合法"""
    return symbol.endswith("USDT")

def within_range(value, min_v, max_v):
    """判断数值是否在区间内"""
    return min_v <= value <= max_v