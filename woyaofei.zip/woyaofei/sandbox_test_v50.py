# 🚀《我要飞合约版》v50 实时波动捕捉 + 入场信号智能判断模块
# -*- coding: utf-8 -*-
# 运行环境：Python 3.10+ / UTF-8
# 依赖库：requests、datetime、time
# 功能：实时抓取币安现货USDT对行情，并智能分析入场信号

import requests
import time
from datetime import datetime

# 币安API接口
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
url = "https://api.binance.com/api/v3/ticker/price"

# ====== 参数设置 ======
波动阈值 = 1.5       # 预测30分钟波动阈值%
采样间隔 = 10         # 秒
采样次数 = 6          # 共采样6次 ≈ 1分钟

历史价格 = {s: [] for s in symbols}

def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        r = requests.get(url, params={"symbol": symbol}, timeout=5)
        return float(r.json()["price"])
    except Exception:
        return None

def 分析信号(symbol, prices):
    if len(prices) < 2:
        return "观望", 0.0
    当前价 = prices[-1]
    起始价 = prices[0]
    涨跌幅 = ((当前价 - 起始价) / 起始价) * 100

    if abs(涨跌幅) < 0.3:
        return "观望", abs(涨跌幅)
    elif 涨跌幅 > 0.3:
        return "试多", 涨跌幅
    else:
        return "试空", abs(涨跌幅)

print(f"{获取时间()} 🚀 启动《我要飞合约版》v50 实时波动捕捉 + 入场信号系统\n")

while True:
    print("="*70)
    for s in symbols:
        价格 = 获取币价(s)
        if not 价格:
            print(f"❌ {s} 获取失败，跳过。")
            continue
        历史价格[s].append(价格)
        if len(历史价格[s]) > 采样次数:
            历史价格[s].pop(0)

        信号, 波动 = 分析信号(s, 历史价格[s])
        建议 = "轻仓" + 信号 if 信号 != "观望" else "观望"
        print(f"{获取时间()} {s} 当前价：{价格:.2f} USDT | 波动：{波动:.2f}% | 建议：{建议}")

    print("系统运行稳定，继续监控中...\n")
    time.sleep(采样间隔)