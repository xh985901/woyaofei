# 文件名：sandbox_test_v108.py
# 模块名：AI安全防御核心（熔断+误判一体版）
# 功能：整合网络熔断保护、只读模式、极端波动与诱单误判过滤、自我修复日志系统。

import time
import random
from datetime import datetime

class AISafetyDefenseCore:
    """
    模块 v108：AI 安全防御核心（熔断+误判一体版）
    用于监控网络延迟、极端行情波动、庄家诱单等异常；
    触发自动熔断、进入只读模式，并记录日志。
    """

    def __init__(self, latency_threshold=3.0, volatility_threshold=5.0):
        # 参数阈值
        self.latency_threshold = latency_threshold       # 网络延迟阈值（秒）
        self.volatility_threshold = volatility_threshold # 波动率阈值（百分比）
        # 状态变量
        self.readonly_mode = False
        self.last_trigger_time = None
        self.cooldown_time = 180  # 熔断时间（秒）

    def get_network_latency(self):
        """模拟网络延迟检测"""
        latency = round(random.uniform(0.1, 4.5), 2)
        return latency

    def get_market_volatility(self):
        """模拟行情波动检测"""
        volatility = round(random.uniform(0.5, 8.0), 2)
        return volatility

    def detect_spike(self):
        """检测是否出现庄家插针/诱单"""
        spike_detected = random.choice([True, False, False])
        if spike_detected:
            diff = round(random.uniform(0.3, 1.2), 2)
            print(f"⚠️ 检测到盘口插针异动：波动幅度 {diff}%")
        return spike_detected

    def enter_readonly_mode(self, reason: str):
        """触发熔断保护进入只读模式"""
        self.readonly_mode = True
        self.last_trigger_time = datetime.now()
        print(f"\n🚨 触发熔断保护：{reason}")
        print(f"⏳ 系统进入只读模式 {self.cooldown_time} 秒，暂停AI下单。\n")

    def recover_from_readonly(self):
        """恢复正常交易模式"""
        if not self.readonly_mode:
            return
        elapsed = (datetime.now() - self.last_trigger_time).seconds
        if elapsed >= self.cooldown_time:
            self.readonly_mode = False
            print("✅ 熔断结束：AI已恢复正常交易模式。\n")

    def adjust_confidence(self, base_confidence):
        """在极端波动下降低AI信心权重"""
        adjusted = max(base_confidence - random.uniform(10, 25), 0)
        print(f"🤖 调整AI信心：{base_confidence:.1f}% → {adjusted:.1f}%\n")
        return adjusted

    def log_event(self, latency, volatility, status):
        """记录安全事件日志"""
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open("run_v108.log", "a", encoding="utf-8") as f:
            f.write(f"[{now}] 延迟:{latency}s 波动:{volatility}% 状态:{status}\n")

    def run(self):
        """主循环"""
        print("\n🚀 启动 AI 安全防御核心 v108（熔断+误判一体版）")
        print("=============================================\n")

        for cycle in range(1, 8):
            print(f"📊 检测循环 #{cycle}")
            latency = self.get_network_latency()
            volatility = self.get_market_volatility()

            print(f"🌐 当前网络延迟: {latency}s | 实时波动: {volatility}%")

            if latency > self.latency_threshold or volatility > self.volatility_threshold:
                self.enter_readonly_mode(reason=f"延迟{latency}s或波动{volatility}%超阈值")
                self.log_event(latency, volatility, "触发熔断")
                time.sleep(2)
            elif self.detect_spike():
                print("📉 触发假信号过滤，降低AI信心权重。")
                self.adjust_confidence(base_confidence=random.uniform(70, 95))
                self.log_event(latency, volatility, "插针过滤")
                time.sleep(1)
            else:
                print("✅ 一切正常，AI持续监控中...\n")
                self.log_event(latency, volatility, "正常")

            self.recover_from_readonly()
            time.sleep(1.2)

        print("📁 日志已写入：run_v108.log")
        print("🧠 AI安全防御核心执行完成。")

# 主入口
if __name__ == "__main__":
    defense = AISafetyDefenseCore()
    defense.run()