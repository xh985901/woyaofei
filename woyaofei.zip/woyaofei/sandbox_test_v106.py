# ===============================================
# 🧠 sandbox_test_v106.py
# 模块：AI死单自救 + 卡单检测 + 自动延迟补单重试机制
# 功能：防止AI自主下单时出现卡单、空挂、死单；支持延迟补单与自我恢复
# 版本：v106（统一命名与路径）
# ===============================================

import time
import random

class Order:
    def __init__(self, symbol, side, price, volume):
        self.symbol = symbol
        self.side = side
        self.price = price
        self.volume = volume
        self.status = "PENDING"      # PENDING / FILLED / CANCELED / STUCK
        self.created_at = time.time()
        self.last_update = self.created_at

class AIDeadOrderRescue:
    def __init__(self):
        self.dead_orders = 0
        self.retry_limit = 3
        self.retry_delay = 3         # 秒
        self.orders = []
        self.paused_until = 0

    def create_order(self, symbol, side, price, volume):
        if time.time() < self.paused_until:
            print(f"⏸️ AI暂停中，暂不下单 ({symbol})")
            return None

        order = Order(symbol, side, price, volume)
        self.orders.append(order)
        print(f"📥 创建挂单：{symbol} | {side} | {price:.2f} | 状态={order.status}")
        return order

    def monitor_orders(self):
        for order in self.orders:
            if order.status in ["FILLED", "CANCELED"]:
                continue

            age = time.time() - order.created_at
            latency = random.uniform(0.1, 3.0)
            liquidity = random.uniform(0.2, 1.0)
            volatility = random.uniform(0.3, 1.5)

            # 检测卡单（长时间PENDING且延迟高）
            if order.status == "PENDING" and (latency > 2.5 or age > 30):
                order.status = "STUCK"
                print(f"⚠️ 检测到卡单：{order.symbol} | 延迟={latency:.2f}s | 挂单时间={age:.1f}s")
                self.handle_stuck_order(order)
                continue

            # 检测死单
            if liquidity < 0.3 or volatility > 1.2:
                print(f"🚫 检测死单：{order.symbol} | 流动={liquidity:.2f} | 波动={volatility:.2f}")
                self.cancel_order(order)
            else:
                print(f"🟢 正常：{order.symbol} | 延迟={latency:.2f}s | 挂单时间={age:.1f}s")

    def handle_stuck_order(self, order):
        """卡单检测后的自动补单逻辑"""
        print(f"🔍 开始卡单处理：{order.symbol}")
        for attempt in range(1, self.retry_limit + 1):
            time.sleep(self.retry_delay)
            success = random.choice([True, False])
            if success:
                new_price = order.price * (1 + random.uniform(-0.0005, 0.0005))
                order.status = "REPLACED"
                print(f"✅ 第{attempt}次延迟补单成功：{order.symbol} | 新价={new_price:.2f}")
                self.create_order(order.symbol, order.side, new_price, order.volume)
                return
            else:
                print(f"⏳ 第{attempt}次补单失败，重试中...")
        print(f"❌ 卡单恢复失败：{order.symbol}，进入风险冷却。")
        self.trigger_pause()

    def cancel_order(self, order):
        order.status = "CANCELED"
        self.dead_orders += 1
        print(f"🧹 撤销死单：{order.symbol} | 累计死单={self.dead_orders}")
        if self.dead_orders >= 3:
            self.trigger_pause()

    def trigger_pause(self):
        self.paused_until = time.time() + 60
        print(f"🚨 连续异常，AI暂停60秒以防风险。")

    def run_simulation(self):
        print("\n🚀 启动 AI死单+卡单检测系统 v106")
        for i in range(2):
            self.create_order("BTCUSDT", "BUY", 62000 + i * 10, 0.5)
        for i in range(2):
            self.create_order("ETHUSDT", "SELL", 3500 - i * 5, 1.0)

        print("\n⏱️ 启动实时监控...\n")
        for _ in range(3):
            self.monitor_orders()
            time.sleep(1.5)

        print("\n📊 模拟结束，所有异常已检测与处理完毕。")
        print("✅ v106 卡单自救机制沙盒运行完毕 [Program finished]")

# 主入口
if __name__ == "__main__":
    ai = AIDeadOrderRescue()
    ai.run_simulation()