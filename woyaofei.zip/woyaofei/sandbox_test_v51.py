# 🚀《我要飞合约版》v51 入场把握度 + 止盈止损模块
# -*- coding: utf-8 -*-
import requests, time, random
from datetime import datetime

# ===== 币安现货API =====
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
api_url = "https://api.binance.com/api/v3/ticker/price"

# ===== 参数设置 =====
采样间隔 = 10     # 秒
采样次数 = 6      # 采样6次 ≈ 1分钟波动
波动阈值 = 0.5     # 超过0.5%认为有效波动
历史价格 = {s: [] for s in symbols}

def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        res = requests.get(api_url, params={"symbol": symbol}, timeout=5)
        return float(res.json()["price"])
    except:
        return None

def 分析信号(symbol, prices):
    if len(prices) < 2:
        return "观望", 0.0, "低", 0.0, 0.0, 0.0

    当前价 = prices[-1]
    起始价 = prices[0]
    涨跌幅 = ((当前价 - 起始价) / 起始价) * 100

    # === 模拟智能评估 ===
    把握度 = min(100, max(10, abs(涨跌幅) * random.uniform(60, 120)))
    仓位建议 = "轻仓" if 把握度 < 60 else "中仓"
    风险等级 = "低" if abs(涨跌幅) < 0.8 else "中" if abs(涨跌幅) < 1.5 else "高"

    止盈 = 当前价 * (1.01 if 涨跌幅 > 0 else 0.99)
    止损 = 当前价 * (0.99 if 涨跌幅 > 0 else 1.01)

    if abs(涨跌幅) < 波动阈值:
        return "观望", 把握度, 风险等级, 涨跌幅, 止盈, 止损
    elif 涨跌幅 > 0:
        return 仓位建议 + "试多", 把握度, 风险等级, 涨跌幅, 止盈, 止损
    else:
        return 仓位建议 + "试空", 把握度, 风险等级, 涨跌幅, 止盈, 止损

print(f"{获取时间()} 🚀 启动《我要飞合约版》v51 入场把握度 + 止盈止损系统\n")

while True:
    print("="*72)
    for s in symbols:
        价格 = 获取币价(s)
        if not 价格:
            print(f"❌ {s} 获取失败，跳过。")
            continue

        历史价格[s].append(价格)
        if len(历史价格[s]) > 采样次数:
            历史价格[s].pop(0)

        建议, 把握度, 风险, 波动, 止盈, 止损 = 分析信号(s, 历史价格[s])
        print(f"{获取时间()} {s} 当前价：{价格:.2f} USDT | 波动：{波动:.2f}%")
        print(f"➡ 建议：{建议} | 把握度：{把握度:.1f}% | 风险：{风险}")
        if 建议 != "观望":
            print(f"🎯 止盈：{止盈:.2f} | ⛔ 止损：{止损:.2f}")
        print("-"*72)
        time.sleep(1)
    print("系统运行稳定，持续监控中...\n")
    time.sleep(采样间隔)