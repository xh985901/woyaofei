# 文件名：sandbox_test_v109.py
# 模块名：多币种热力榜（Multi-Symbol Heatmap Board）
# 功能：实时对比多币种涨跌、成交量、资金流入强度，生成热度排名。
# 数据源：币安公开行情接口（示例为BTCUSDT/ETHUSDT/SOLUSDT/BNBUSDT/XRPUSDT）

import requests
import time
from datetime import datetime
import random

class MultiSymbolHeatmap:
    """
    模块 v109：多币种热力榜
    说明：
        - 每30秒刷新一次指定币种行情
        - 计算短周期涨跌幅、成交额变化、资金热度评分
        - 实时打印热力榜（Top 5）
    """

    def __init__(self, symbols=None, refresh_interval=30):
        if symbols is None:
            symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"]
        self.symbols = symbols
        self.refresh_interval = refresh_interval
        self.api_base = "https://api.binance.com/api/v3/ticker/24hr"
        self.history = {}  # 保存前一周期价格、成交量

    def fetch_symbol_data(self, symbol):
        """从币安拉取单币种数据"""
        try:
            res = requests.get(self.api_base, params={"symbol": symbol})
            data = res.json()
            price = float(data.get("lastPrice", 0))
            volume = float(data.get("quoteVolume", 0))
            change = float(data.get("priceChangePercent", 0))
            return price, volume, change
        except Exception as e:
            print(f"⚠️ 无法获取 {symbol} 数据：{e}")
            return 0, 0, 0

    def compute_heat_score(self, symbol, price, volume, change):
        """根据涨跌、成交量、波动，生成热度评分"""
        prev = self.history.get(symbol, {"price": price, "volume": volume})
        price_diff = abs(price - prev["price"]) / prev["price"] * 100 if prev["price"] else 0
        vol_diff = (volume - prev["volume"]) / prev["volume"] * 100 if prev["volume"] else 0
        random_factor = random.uniform(0.9, 1.1)  # 模拟实时波动差异
        heat = (abs(change) * 0.5 + price_diff * 0.3 + vol_diff * 0.2) * random_factor
        self.history[symbol] = {"price": price, "volume": volume}
        return round(heat, 2)

    def display_heatmap(self, results):
        """打印热力榜"""
        print("\n🔥 多币种热力榜（v109）")
        print("============================================")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"更新时间：{now}\n")
        sorted_list = sorted(results.items(), key=lambda x: x[1]["heat"], reverse=True)
        for idx, (symbol, data) in enumerate(sorted_list, start=1):
            arrow = "📈" if data["change"] > 0 else "📉"
            print(f"{idx}. {symbol:<8} {arrow} 涨幅: {data['change']:+6.2f}% | "
                  f"热度值: {data['heat']:6.2f} | 价格: {data['price']:>10.2f} USDT")
        print("============================================\n")

    def run(self):
        print("\n🚀 启动多币种热力榜模块 v109")
        print("监控币种：", ", ".join(self.symbols))
        print("--------------------------------------------")

        for cycle in range(1, 6):  # 模拟运行5轮
            results = {}
            for sym in self.symbols:
                price, volume, change = self.fetch_symbol_data(sym)
                heat = self.compute_heat_score(sym, price, volume, change)
                results[sym] = {"price": price, "change": change, "heat": heat}
            self.display_heatmap(results)
            time.sleep(self.refresh_interval)

        print("✅ 多币种热力榜任务完成。\n")

# 主入口
if __name__ == "__main__":
    heatmap = MultiSymbolHeatmap()
    heatmap.run()