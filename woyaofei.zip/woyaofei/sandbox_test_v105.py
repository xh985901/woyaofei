# ===============================================
# 🧠 sandbox_test_v105.py
# 模块：AI死单自救引擎 + 异常挂单恢复系统
# 功能：防止AI自主下单时出现空挂、死单、卡单
# 版本：v105（统一命名与路径）
# ===============================================

import time
import random

# 模拟订单结构
class Order:
    def __init__(self, symbol, side, price, volume):
        self.symbol = symbol
        self.side = side
        self.price = price
        self.volume = volume
        self.status = "NEW"          # 可能状态：NEW / PARTIAL / FILLED / CANCELED
        self.create_time = time.time()
        self.last_update = self.create_time

# 模拟AI策略与死单检测逻辑
class AIDeadOrderRecovery:
    def __init__(self):
        self.dead_order_count = 0
        self.paused_until = 0
        self.orders = []
        self.logs = []

    def create_order(self, symbol, side, price, volume):
        if time.time() < self.paused_until:
            print(f"⏸️ AI暂停中，暂不下单 ({symbol})")
            return None

        order = Order(symbol, side, price, volume)
        self.orders.append(order)
        print(f"📥 创建新挂单 {symbol} | 方向={side} | 价格={price:.2f} | 状态=NEW")
        return order

    def monitor_orders(self):
        for order in self.orders:
            if order.status in ["FILLED", "CANCELED"]:
                continue

            age = time.time() - order.create_time
            volatility = random.uniform(0.3, 1.5)      # 模拟波动性
            liquidity = random.uniform(0.1, 1.0)       # 模拟流动性比例

            # 死单检测条件
            if age > 120 or liquidity < 0.3 or volatility > 1.2:
                print(f"⚠️ 检测到死单 {order.symbol} | 年龄={age:.0f}s | 成交流动性={liquidity:.2f} | 波动={volatility:.2f}")
                self.recover_dead_order(order)
            else:
                print(f"🟢 正常挂单 {order.symbol} | 年龄={age:.0f}s | 成交流动性={liquidity:.2f}")

    def recover_dead_order(self, order):
        order.status = "CANCELED"
        self.dead_order_count += 1
        self.logs.append({
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "symbol": order.symbol,
            "price": order.price,
            "action": "CANCELLED",
            "reason": "Dead Order Detected"
        })
        print(f"🚫 撤销死单：{order.symbol} | 原价={order.price:.2f}")

        # AI快速复评估
        ai_confidence = random.uniform(0.7, 1.0)
        print(f"🤖 AI复评估信心={ai_confidence:.2%}")

        if ai_confidence > 0.9:
            new_price = order.price * (1 + random.uniform(-0.001, 0.001))
            print(f"🔁 智能补单触发，新价格={new_price:.2f}")
            self.create_order(order.symbol, order.side, new_price, order.volume)

        # 安全锁：连续死单三次暂停AI
        if self.dead_order_count >= 3:
            self.paused_until = time.time() + 60
            print(f"🚨 触发安全锁！AI暂停60秒以防连续死单风险。")
            self.dead_order_count = 0

    def run_simulation(self):
        print("\n🚀 启动 AI死单自救系统 v105")
        for i in range(3):
            self.create_order("BTCUSDT", "BUY", 62000 + i * 10, 0.5)
        for i in range(3):
            self.create_order("ETHUSDT", "SELL", 3500 - i * 5, 1.0)

        print("\n⏱️ 开始监控挂单状态...")
        for _ in range(3):
            self.monitor_orders()
            time.sleep(1.5)

        print("\n📊 模拟完成，所有死单检测与自救已执行完毕。")
        print(f"🧾 日志总数：{len(self.logs)} 条\n")
        for log in self.logs[-5:]:
            print(f"🕒 {log['time']} | {log['symbol']} | {log['action']} | 原因={log['reason']}")

# 主执行入口
if __name__ == "__main__":
    ai = AIDeadOrderRecovery()
    ai.run_simulation()
    print("\n✅ v105 死单自救系统沙盒运行完毕 [Program finished]")