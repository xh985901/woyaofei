# ===========================================
sandbox_test_v121.py
# ===========================================

import pandas as pd
import numpy as np
import datetime
from pathlib import Path

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class FakeSignalDetector:
    """
    实盘假信号检测模块：
      - 通过撤单率、成交集中度、反转率判定市场操纵或诱导行为；
      - 可接入实时交易数据流或历史数据；
      - 兼容 BeeWare Android 打包环境。
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("FakeSignalDetector")

        self.data_dir = Path(self.cfg.get("data_dir"))
        self.report_dir = Path(self.cfg.get("report_dir"))
        self.result_path = self.report_dir / "fake_signal_report.csv"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.report_dir.mkdir(parents=True, exist_ok=True)

        # 检测参数（可调）
        self.cancel_rate_threshold = 0.4      # 撤单率阈值 >40%
        self.concentration_threshold = 0.35   # 成交集中度阈值
        self.reversal_threshold = 0.8         # 快速反转比例阈值

        self.logger.info("FakeSignalDetector 实盘模块初始化完成", {
            "cancel_rate_threshold": self.cancel_rate_threshold,
            "data_dir": str(self.data_dir)
        })

    # ---------- 数据加载 ----------
    def load_sample_data(self) -> pd.DataFrame:
        """
        加载实盘或样本数据，若无则自动生成模拟数据。
        """
        sample_path = self.data_dir / "sample_trades.csv"
        if not sample_path.exists():
            np.random.seed(42)
            df = pd.DataFrame({
                "time": pd.date_range(datetime.datetime.now(), periods=100, freq="1min"),
                "cancel_ratio": np.random.uniform(0, 0.8, 100),
                "trade_concentration": np.random.uniform(0, 0.5, 100),
                "reversal_ratio": np.random.uniform(0, 1, 100),
            })
            try:
                df.to_csv(sample_path, index=False)
                self.logger.warning(f"⚠️ 未找到样本数据，已生成模拟数据 {sample_path}")
            except Exception as e:
                self.logger.error(f"写入模拟数据失败: {e}")
        try:
            return pd.read_csv(sample_path)
        except Exception as e:
            self.logger.error(f"加载数据失败: {e}")
            return pd.DataFrame(columns=["cancel_ratio", "trade_concentration", "reversal_ratio"])

    # ---------- 核心检测 ----------
    def detect_fake_signals(self, df: pd.DataFrame) -> int:
        """
        计算假信号指标并输出检测结果。
        返回检测出的可疑信号数。
        """
        if df.empty:
            self.logger.warning("⚠️ 输入数据为空，无法检测假信号")
            return 0

        df["fake_cancel"] = df["cancel_ratio"] > self.cancel_rate_threshold
        df["fake_concentration"] = df["trade_concentration"] > self.concentration_threshold
        df["fake_reversal"] = df["reversal_ratio"] > self.reversal_threshold

        # 计算综合假信号评分
        df["fake_score"] = (
            df["cancel_ratio"].clip(0, 1) * 0.4 +
            df["trade_concentration"].clip(0, 1) * 0.3 +
            df["reversal_ratio"].clip(0, 1) * 0.3
        ).clip(0, 1)

        df["fake_flag"] = df["fake_score"] > 0.65

        suspicious_count = int(df["fake_flag"].sum())
        avg_score = round(df["fake_score"].mean(), 3)

        try:
            df.to_csv(self.result_path, index=False, encoding="utf-8-sig")
            self.logger.info(f"✅ 假信号检测完成，疑似信号 {suspicious_count} 条，平均得分 {avg_score}")
        except Exception as e:
            self.logger.error(f"写入检测结果失败: {e}")

        return suspicious_count

    # ---------- 主执行入口 ----------
    def run_analysis(self):
        df = self.load_sample_data()
        suspicious_count = self.detect_fake_signals(df)
        self.logger.info(f"📊 实盘检测完毕 | 可疑信号数: {suspicious_count}")


# ---------- 独立执行 ----------
if __name__ == "__main__":
    fsd = FakeSignalDetector()
    fsd.run_analysis()