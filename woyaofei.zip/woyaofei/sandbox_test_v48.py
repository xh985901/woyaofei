# ================================
#  sandbox_test_v48_final.py
#  Binance Read-Only API Test (UTF-8 Locked Version)
# ================================

import os, sys, time, json
import requests

# --- 强制全局 UTF-8 输出 ---
os.environ["PYTHONIOENCODING"] = "utf-8"
os.environ["PYTHONUTF8"] = "1"
sys.stdout.reconfigure(encoding='utf-8')

print("[System] Launching v48-Final Binance Read-Only API Test (UTF-8 locked)...\n")

# --- 币安API端点 ---
API_BASE = "https://api.binance.com/api/v3/ticker/price"
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

results = []
for sym in symbols:
    try:
        url = f"{API_BASE}?symbol={sym}"
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            price = float(data["price"])
            results.append((sym, price))
            print(f"[OK] {sym} | Price: {price:.2f} | Connection: Stable")
        else:
            print(f"[WARN] {sym} | HTTP Status: {response.status_code} | Retrying...")
    except Exception as e:
        msg = str(e).encode("utf-8", errors="ignore").decode("utf-8")
        print(f"[ERROR] {sym} fetch failed: {msg}")
    time.sleep(1)

print("\n---------------------------------------")
if results:
    print("[Summary] Binance API returned data successfully.")
    for sym, price in results:
        print(f"  {sym}: {price:.2f} USDT")
else:
    print("[Summary] No valid data received. Please check your API key or network.")

with open("report_v48_final.txt", "w", encoding="utf-8") as f:
    f.write("Binance Read-Only API Test Report (v48-Final)\n")
    if results:
        for sym, price in results:
            f.write(f"{sym}: {price:.2f} USDT\n")
    else:
        f.write("No valid data received.\n")

print("\n[System] v48-Final completed. Report saved as report_v48_final.txt.")