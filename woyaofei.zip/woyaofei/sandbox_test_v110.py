# ===========================================
# 文件名 : real_market_monitor_v110.py
# 版本   : 实盘版 v1.0
# 说明   : 实时行情监控与异常检测模块（可用于真实环境）
# 作者   : JACK & GPT 实盘协作
# 日期   : 2025-11-02
# ===========================================

import os
import time
import json
import requests
import pandas as pd
from datetime import datetime

# 默认设置
API_BASE = "https://api.binance.com"
SYMBOL_DEFAULT = "BTCUSDT"
INTERVAL_DEFAULT = "1h"
LOOKBACK_LIMIT = 500  # 拉取K线数量

REPORT_DIR = os.path.join(os.getcwd(), "reports")
os.makedirs(REPORT_DIR, exist_ok=True)

class RealMarketMonitor:
    """
    实盘行情监控模块：
      - 实时从 Binance 拉取K线数据
      - 计算特征（波动、速度、成交量变化等）
      - 检测市场异常
      - 输出结果到日志文件（Android 兼容）
    """

    def __init__(self, symbol=SYMBOL_DEFAULT, interval=INTERVAL_DEFAULT):
        self.symbol = symbol.upper()
        self.interval = interval
        self.df = None
        self.log_path = os.path.join(REPORT_DIR, f"market_monitor_{symbol}_{interval}_{int(time.time())}.txt")

    # ----------- 数据获取部分 -----------
    def fetch_candles(self, limit=LOOKBACK_LIMIT):
        """从 Binance 获取最新K线"""
        url = f"{API_BASE}/api/v3/klines"
        params = {"symbol": self.symbol, "interval": self.interval, "limit": limit}
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code != 200:
            raise RuntimeError(f"获取行情失败：{resp.status_code} {resp.text}")

        data = resp.json()
        df = pd.DataFrame(data, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_asset_volume", "num_trades",
            "taker_buy_base", "taker_buy_quote", "ignore"
        ])
        df = df[["open_time", "open", "high", "low", "close", "volume", "close_time"]]
        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
        df["close_time"] = pd.to_datetime(df["close_time"], unit="ms")
        df[["open", "high", "low", "close", "volume"]] = df[["open", "high", "low", "close", "volume"]].astype(float)
        self.df = df

    # ----------- 特征计算 -----------
    def compute_features(self):
        """计算特征指标"""
        df = self.df.copy()
        df["return"] = df["close"].pct_change().fillna(0)
        df["vol_ma"] = df["volume"].rolling(window=20, min_periods=3).mean().fillna(method="bfill")
        df["vol_zscore"] = (df["volume"] - df["vol_ma"]) / (df["volume"].rolling(window=20, min_periods=3).std().replace(0, 1))
        df["speed"] = df["volume"].diff().fillna(0)
        df["speed_z"] = (df["speed"] - df["speed"].rolling(window=20, min_periods=3).mean().fillna(0)) / (df["speed"].rolling(window=20, min_periods=3).std().replace(0, 1))
        df["price_range"] = (df["high"] - df["low"]) / df["open"].replace(0, 1)
        df["range_ma"] = df["price_range"].rolling(window=20, min_periods=3).mean().fillna(0)
        self.df = df

    # ----------- 异常检测逻辑 -----------
    def detect_anomalies(self, idx):
        """检测单个时间点的异常信号"""
        row = self.df.iloc[idx]
        alerts = []
        if row["vol_zscore"] > 3:
            alerts.append({"type": "volume_spike", "score": float(row["vol_zscore"])})
        if row["speed_z"] > 3:
            alerts.append({"type": "speed_spike", "score": float(row["speed_z"])})
        if row["price_range"] > row["range_ma"] * 3:
            alerts.append({"type": "large_range", "score": float(row["price_range"] / (row["range_ma"] + 1e-9))})
        return alerts

    def compute_confidence(self, alerts):
        """综合打分"""
        if not alerts:
            return 0
        score = sum(min(5, abs(a["score"])) for a in alerts)
        return min(100, int(score / len(alerts) * 10))

    # ----------- 运行与日志 -----------
    def log_event(self, event):
        """写入日志文件"""
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")

    def run_once(self):
        """单次执行流程"""
        self.fetch_candles()
        self.compute_features()
        latest = self.df.iloc[-1]
        alerts = self.detect_anomalies(len(self.df) - 1)
        confidence = self.compute_confidence(alerts)
        snapshot = {
            "time": latest["open_time"].strftime("%Y-%m-%d %H:%M:%S"),
            "symbol": self.symbol,
            "close": float(latest["close"]),
            "alerts": alerts,
            "confidence_percent": confidence
        }
        self.log_event(snapshot)
        print(json.dumps(snapshot, ensure_ascii=False))
        return snapshot

    def run_loop(self, interval=60):
        """循环执行，每隔 interval 秒检测一次"""
        print(f"开始实时监控 {self.symbol} ({self.interval})，日志：{self.log_path}")
        while True:
            try:
                snap = self.run_once()
                time.sleep(interval)
            except KeyboardInterrupt:
                print("监控中止。")
                break
            except Exception as e:
                print("运行异常：", e)
                time.sleep(5)

# ---------- 模块独立运行 ----------
if __name__ == "__main__":
    monitor = RealMarketMonitor("BTCUSDT", "1h")
    monitor.run_loop(interval=60)