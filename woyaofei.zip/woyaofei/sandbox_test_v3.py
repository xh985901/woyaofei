# ===============================================================
# 模块06：阶梯止盈止损（StepTakeProfitStopLoss）
# 功能：分批止盈止损，防止一刀切，锁定收益。
# ===============================================================

class StepTakeProfitStopLoss:
    def __init__(self, tp_levels=None, sl_levels=None):
        self.tp_levels = tp_levels or [0.02, 0.04, 0.06]   # 止盈百分比
        self.sl_levels = sl_levels or [0.01, 0.02]         # 止损百分比
        self.executed_tp = set()
        self.executed_sl = set()

    def check_take_profit(self, entry_price, current_price):
        """检测是否触发止盈"""
        change = (current_price - entry_price) / entry_price
        for level in self.tp_levels:
            if change >= level and level not in self.executed_tp:
                print(f"✅ 止盈 {level*100:.1f}% 已触发！")
                self.executed_tp.add(level)
                return True
        return False

    def check_stop_loss(self, entry_price, current_price):
        """检测是否触发止损"""
        change = (entry_price - current_price) / entry_price
        for level in self.sl_levels:
            if change >= level and level not in self.executed_sl:
                print(f"⚠️ 止损 {level*100:.1f}% 已触发！")
                self.executed_sl.add(level)
                return True
        return False


# ===============================================================
# 模块07：智能区间止损止盈 + 假突破过滤（SmartZoneStop）
# 功能：通过滑距与量能判断，减少假突破损失。
# ===============================================================

class SmartZoneStop:
    def __init__(self, atr_ratio=1.5):
        self.atr_ratio = atr_ratio
        self.last_decision = None

    def check_breakout(self, price, avg_price, atr, volume, avg_volume):
        """判断是否假突破"""
        if abs(price - avg_price) < atr * self.atr_ratio and volume < avg_volume * 1.3:
            print("🟡 疑似假突破，等待确认…")
            return False
        return True

    def confirm_entry(self, signal_strength):
        """信号强度足够才允许入场"""
        if signal_strength >= 0.7:
            self.last_decision = "ENTRY_CONFIRMED"
            print("✅ 入场信号确认。")
            return True
        else:
            print("❌ 入场信号不足，放弃。")
            return False


# ===============================================================
# 模块08：高倍速战模式（QuickBattleMode）
# 功能：一键高倍进场，每日仅限一次，防止重复开仓。
# ===============================================================

import datetime

class QuickBattleMode:
    def __init__(self, leverage=10):
        self.leverage = leverage
        self.last_trade_date = None

    def can_trade_today(self):
        today = datetime.date.today()
        return self.last_trade_date != today

    def execute_trade(self, side, size):
        """执行一次高倍交易"""
        if not self.can_trade_today():
            print("⚠️ 今日已执行高倍交易，锁定。")
            return False
        print(f"🚀 执行{side}单，倍数: {self.leverage}，仓位: {size}")
        self.last_trade_date = datetime.date.today()
        return True


# ===============================================================
# 模块09：自动加减仓 / 倍数调整（AutoPositionManager）
# 功能：根据胜率动态调整仓位与杠杆。
# ===============================================================

class AutoPositionManager:
    def __init__(self, base_size=1.0, base_leverage=5):
        self.base_size = base_size
        self.base_leverage = base_leverage

    def adjust(self, win_rate):
        """根据胜率调整仓位与倍数"""
        if win_rate >= 0.8:
            size = self.base_size * 1.5
            leverage = self.base_leverage * 1.5
        elif win_rate >= 0.7:
            size = self.base_size
            leverage = self.base_leverage
        else:
            size = self.base_size * 0.5
            leverage = self.base_leverage * 0.5
        print(f"🔧 仓位调整: {size:.2f} 倍, 杠杆 {leverage:.2f}")
        return size, leverage


# ===============================================================
# 模块10：模拟测试（SimulationModule）
# 功能：假资金 + 盈亏统计，便于安全测试。
# ===============================================================

class SimulationModule:
    def __init__(self, init_balance=10000):
        self.balance = init_balance
        self.trades = []

    def execute_trade(self, side, entry_price, exit_price, size=1.0, fee=0.0005):
        """执行一笔模拟交易"""
        pnl = (exit_price - entry_price) / entry_price * size
        if side.lower() == "sell":
            pnl *= -1
        pnl -= fee
        self.balance *= (1 + pnl)
        self.trades.append(pnl)
        print(f"💰 模拟{side}交易完成，收益: {pnl*100:.2f}%，余额: {self.balance:.2f}")
        return pnl

    def summary(self):
        """输出交易汇总"""
        total = len(self.trades)
        win = sum(1 for p in self.trades if p > 0)
        print(f"📊 模拟结束，共{total}单，胜率 {win/total*100:.1f}% ，最终余额 {self.balance:.2f}")


# ===============================================================
# 模块11：盈亏显示（PnLDisplay）
# 功能：展示每笔盈亏、日汇总与累计曲线。
# ===============================================================

class PnLDisplay:
    def __init__(self):
        self.records = []

    def record(self, trade_pnl):
        self.records.append(trade_pnl)

    def show_summary(self):
        total = sum(self.records)
        avg = total / len(self.records) if self.records else 0
        print(f"📈 当前累计收益 {total*100:.2f}% | 平均每单 {avg*100:.2f}%")

    def reset(self):
        self.records = []


# ===============================================================
# 模块03修复：趋势分析（TrendAnalyzer）
# 用于提供 run_test()，防止“未定义”错误
# ===============================================================

class TrendAnalyzer:
    def __init__(self):
        print("📊 TrendAnalyzer 模拟初始化完成")

    def run_test(self):
        print("✅ 模块03 测试运行成功，趋势分析模块已联通。")


# ===============================================================
# 启动测试
# ===============================================================

if __name__ == "__main__":
    print("🚀 启动模块测试中…")

    trend = TrendAnalyzer()
    trend.run_test()

    tp_sl = StepTakeProfitStopLoss()
    tp_sl.check_take_profit(100, 106)
    tp_sl.check_stop_loss(100, 97)

    smart = SmartZoneStop()
    smart.check_breakout(105, 100, 3, 200, 250)
    smart.confirm_entry(0.8)

    quick = QuickBattleMode()
    quick.execute_trade("buy", 1.0)

    auto = AutoPositionManager()
    auto.adjust(0.85)

    sim = SimulationModule()
    sim.execute_trade("buy", 100, 110)
    sim.summary()

    pnl = PnLDisplay()
    pnl.record(0.05)
    pnl.record(-0.02)
    pnl.show_summary()

    print("✅ 全部模块测试完毕。")