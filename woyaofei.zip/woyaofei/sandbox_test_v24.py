# -*- coding: utf-8 -*-
# 🚀 《我要飞合约版》v24 情绪+趋势融合联动测试版
# 北京时间自动标记版
import datetime
import random

def now_beijing():
    return datetime.datetime.utcnow() + datetime.timedelta(hours=8)

def analyze_trend(symbol):
    """模拟趋势与波动模块（v19基础）"""
    mode = random.choice(["趋势", "异常波动", "震荡"])
    direction = random.choice(["上涨", "下跌", "横盘"])
    strength = round(random.uniform(0.8, 3.0), 2)
    return {"symbol": symbol, "mode": mode, "direction": direction, "strength": strength}

def analyze_sentiment(symbol):
    """模拟情绪面分析模块（v23骨架）"""
    sentiment_score = random.randint(5, 95)
    flow = random.choice(["流入", "流出"])
    return {"symbol": symbol, "sentiment": sentiment_score, "flow": flow}

def fuse_analysis(trend, sentiment):
    """情绪+趋势融合逻辑"""
    s = sentiment["sentiment"]
    trend_dir = trend["direction"]
    final = trend_dir
    advice = "观望"
    note = ""

    if s < 30:  # 恐慌
        if trend_dir == "上涨":
            final = "修正为震荡"
            advice = "⚠️ 谨慎观望"
            note = "情绪恐慌压制上涨"
        else:
            advice = "✅ 顺势空头"
            note = "情绪助跌"
    elif s > 70:  # 贪婪
        if trend_dir == "下跌":
            final = "修正为震荡"
            advice = "⚠️ 谨慎观望"
            note = "贪婪情绪延迟修正"
        else:
            advice = "✅ 顺势多头"
            note = "情绪助涨"
    else:  # 中性
        advice = "👀 继续观察"
        note = "市场中性，趋势保持原样"

    return {
        "symbol": trend["symbol"],
        "mode": trend["mode"],
        "direction": final,
        "strength": trend["strength"],
        "sentiment": s,
        "advice": advice,
        "note": note
    }

def main():
    print(f"[{now_beijing().strftime('%Y-%m-%d %H:%M:%S')}] 🚀 启动《我要飞合约版》v24 情绪+趋势融合联动测试引擎……\n")

    coins = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
    results = []

    for c in coins:
        t = analyze_trend(c)
        s = analyze_sentiment(c)
        fused = fuse_analysis(t, s)
        results.append(fused)

        print(f"📊 币种: {c}")
        print(f"模式: {fused['mode']} | 趋势: {fused['direction']} | 强度: {fused['strength']}")
        print(f"情绪分: {fused['sentiment']} | 建议: {fused['advice']} | 说明: {fused['note']}\n")

    avg_sent = sum([r['sentiment'] for r in results]) / len(results)
    avg_strength = sum([r['strength'] for r in results]) / len(results)
    print("=="*30)
    print(f"🧩 平均情绪分: {avg_sent:.1f} | 平均强度: {avg_strength:.2f}")
    print("✅ 所有模块执行完毕，系统运行正常。")

    with open("report_v24.txt", "w", encoding="utf-8") as f:
        for r in results:
            f.write(str(r) + "\n")

if __name__ == "__main__":
    main()