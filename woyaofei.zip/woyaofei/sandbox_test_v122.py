# ===========================================
sandbox_test_v122.py
# ===========================================

import time
import uuid
import hmac
import hashlib
import requests
import json
from datetime import datetime
from collections import defaultdict, deque
import threading

# ---------- 常量区 ----------
DEFAULT_FEE_RATE = 0.001  # 实盘统一为 0.1%
MIN_TICK = 0.01
API_TIMEOUT = 10
# ----------------------------------------------------

def now_ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def gen_order_id():
    return str(uuid.uuid4()).replace("-", "")[:16]

# ---------- 实盘账户账本 ----------
class Ledger:
    """
    真实账户账本：
      - 自动从交易所 API 拉取余额
      - 支持手动缓存
      - 提供余额快照与资金变化日志
    """
    def __init__(self, api_client):
        self.api = api_client
        self.balances = defaultdict(lambda: {"available": 0.0, "locked": 0.0})
        self.update_balances()

    def update_balances(self):
        try:
            bal_data = self.api.get_balances()
            for item in bal_data:
                asset = item["asset"]
                free = float(item.get("free", 0))
                locked = float(item.get("locked", 0))
                self.balances[asset] = {"available": free, "locked": locked}
        except Exception as e:
            print(f"[Ledger] 更新余额失败: {e}")

    def get_balance(self, asset):
        b = self.balances.get(asset, {"available": 0.0, "locked": 0.0})
        return {"available": round(b["available"], 8), "locked": round(b["locked"], 8)}

    def snapshot(self):
        return {k: v for k, v in self.balances.items()}

# ---------- 实盘交易接口 ----------
class ExchangeClient:
    """
    对接真实交易所（默认 Binance Spot）。
    需配置 api_key, api_secret。
    """
    def __init__(self, api_key, api_secret, base_url="https://api.binance.com"):
        self.key = api_key
        self.secret = api_secret.encode()
        self.url = base_url

    def _sign(self, params):
        query = "&".join([f"{k}={v}" for k, v in params.items()])
        sig = hmac.new(self.secret, query.encode(), hashlib.sha256).hexdigest()
        return sig

    def _headers(self):
        return {"X-MBX-APIKEY": self.key}

    # ---------- 下单 ----------
    def place_order(self, symbol, side, qty, price=None, order_type="LIMIT"):
        endpoint = "/api/v3/order"
        params = {
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": qty,
            "timestamp": int(time.time() * 1000)
        }
        if price:
            params["price"] = price
            params["timeInForce"] = "GTC"

        params["signature"] = self._sign(params)
        resp = requests.post(self.url + endpoint, headers=self._headers(), params=params, timeout=API_TIMEOUT)
        return resp.json()

    # ---------- 获取账户余额 ----------
    def get_balances(self):
        endpoint = "/api/v3/account"
        params = {"timestamp": int(time.time() * 1000)}
        params["signature"] = self._sign(params)
        resp = requests.get(self.url + endpoint, headers=self._headers(), params=params, timeout=API_TIMEOUT)
        data = resp.json()
        return data.get("balances", [])

    # ---------- 查询订单 ----------
    def get_order(self, symbol, order_id):
        endpoint = "/api/v3/order"
        params = {"symbol": symbol, "orderId": order_id, "timestamp": int(time.time() * 1000)}
        params["signature"] = self._sign(params)
        resp = requests.get(self.url + endpoint, headers=self._headers(), params=params, timeout=API_TIMEOUT)
        return resp.json()# ===========================================
# 段 : 2 / 3
# 功能 : 实盘交易执行引擎 + 风控 + 模型接口桥接
# ===========================================

import traceback
import math

# ---------- 实盘交易执行引擎 ----------
class TradeEngine:
    """
    TradeEngine（实盘版）：
      - 接收信号（buy/sell/hold）并通过 ExchangeClient 执行真实下单。
      - 自动记录日志、校验余额与风控。
    """
    def __init__(self, api_client: ExchangeClient, ledger: Ledger, fee_rate=DEFAULT_FEE_RATE):
        self.api = api_client
        self.ledger = ledger
        self.fee_rate = fee_rate
        self.trade_log = []
        self.base_symbol = "USDT"
        self.quote_symbol = "BTC"
        self.symbol_pair = f"{self.quote_symbol}{self.base_symbol}"
        self.max_position = 0.05  # 每次最大买入0.05BTC
        self.min_order_value = 10  # 最小下单10USDT

    # ---------- 风控 ----------
    def check_balance(self, side, qty, price):
        self.ledger.update_balances()
        if side == "BUY":
            need = qty * price
            bal = self.ledger.get_balance(self.base_symbol)["available"]
            if bal < need:
                raise ValueError(f"余额不足：需要 {need} {self.base_symbol}，可用 {bal}")
        else:
            bal = self.ledger.get_balance(self.quote_symbol)["available"]
            if bal < qty:
                raise ValueError(f"{self.quote_symbol} 数量不足：需 {qty}，可用 {bal}")

    def execute_order(self, side, qty, price=None, order_type="LIMIT"):
        try:
            self.check_balance(side, qty, price or 0)
            resp = self.api.place_order(
                symbol=self.symbol_pair,
                side=side,
                qty=qty,
                price=price,
                order_type=order_type
            )
            self.trade_log.append(resp)
            print(f"[TradeEngine] 下单成功 {side} {qty}@{price or 'MKT'} → {resp}")
            return resp
        except Exception as e:
            err = f"[TradeEngine] 下单失败: {e}\n{traceback.format_exc()}"
            print(err)
            self.trade_log.append({"error": str(e)})
            return {"status": "error", "message": str(e)}

    # ---------- 信号执行 ----------
    def on_signal(self, signal, ref_price):
        """
        接收策略信号并执行真实交易：
          - signal: "buy" / "sell" / "wait"
          - ref_price: 参考价格（最新行情）
        """
        if signal == "buy":
            qty = round(min(self.max_position, self.ledger.get_balance(self.base_symbol)["available"] / ref_price), 4)
            if qty * ref_price < self.min_order_value:
                print("[TradeEngine] 可用余额不足，跳过买入。")
                return
            self.execute_order("BUY", qty, price=ref_price)
        elif signal == "sell":
            qty = round(min(self.max_position, self.ledger.get_balance(self.quote_symbol)["available"]), 4)
            if qty * ref_price < self.min_order_value:
                print("[TradeEngine] 可用数量不足，跳过卖出。")
                return
            self.execute_order("SELL", qty, price=ref_price)
        else:
            print("[TradeEngine] 保持观望。")

# ---------- 模型接口 ----------
class MetaReactionModel:
    """
    实盘预测模型：
      - 支持载入预训练模型或使用启发式算法。
      - 返回市场情绪概率。
    """
    def __init__(self, model_path=None):
        self.model_path = model_path
        self.model = None

    def heuristic_score(self, feature_row):
        drr = abs(feature_row.get("depth_ratio_ratio", 0))
        sr = abs(feature_row.get("speed_ratio", 0))
        imb_diff = abs(feature_row.get("imbalance_diff", 0))
        excite = max(0.0, min(1.0, 0.6 * sr + 0.3 * drr))
        fraud = max(0.0, min(1.0, 0.5 * imb_diff + 0.4 * drr))
        silent = max(0.0, 1.0 - (excite + fraud)/1.5)
        s = excite + fraud + silent + 1e-9
        probs = {"excite": round(excite/s, 3), "fraud": round(fraud/s, 3), "silent": round(silent/s, 3)}
        return probs

    def predict_probs(self, feature):
        # 可后续接入真实行情数据
        return self.heuristic_score(feature)# ===========================================
# 段 : 3 / 3
# 功能 : 策略主循环 + 实盘行情采集 + 日志系统 + 主入口
# ===========================================

import os
import time
import random

class MetaReactionPredictorApp:
    """
    实盘交易主循环：
      - 定期拉取行情（来自交易所API）
      - 计算特征，调用 MetaReactionModel 输出预测
      - 根据信号执行实盘交易（TradeEngine）
      - 输出日志与账户快照
    """
    def __init__(self, api_key, api_secret):
        # 初始化API客户端
        self.api_client = ExchangeClient(api_key, api_secret)
        # 初始化账户账本
        self.ledger = Ledger(self.api_client)
        # 初始化模型与交易引擎
        self.model = MetaReactionModel()
        self.engine = TradeEngine(self.api_client, self.ledger)
        # 历史与日志
        self.history = []
        self.log_file = f"trade_log_{int(time.time())}.txt"

    def log(self, msg):
        print(msg)
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    def fetch_market_feature(self):
        """
        从交易所API抓取市场数据（简化版：仅取盘口与价格）
        """
        try:
            resp = requests.get("https://api.binance.com/api/v3/ticker/bookTicker?symbol=BTCUSDT", timeout=5)
            data = resp.json()
            bid = float(data["bidPrice"])
            ask = float(data["askPrice"])
            mid = (bid + ask) / 2.0
            feature = {
                "depth_ratio_ratio": (ask - bid) / mid,
                "speed_ratio": random.uniform(-0.5, 0.5),  # 可后续换为真实成交速率
                "imbalance_diff": random.uniform(-1, 1),
                "mid_price": mid,
                "t_index": int(time.time())
            }
            return feature
        except Exception as e:
            self.log(f"[行情错误] {e}")
            return None

    def run_once(self):
        """
        执行一次预测与实盘下单逻辑
        """
        feature = self.fetch_market_feature()
        if not feature:
            self.log("[警告] 无法获取行情，跳过本轮。")
            return

        probs = self.model.predict_probs(feature)
        signal = "wait"
        if probs["excite"] > 0.6 and probs["fraud"] < 0.3:
            signal = "buy"
        elif probs["fraud"] > 0.6:
            signal = "sell"

        msg = f"[{now_ts()}] 行情={feature['mid_price']:.2f} → 概率={probs} → 信号={signal}"
        self.log(msg)

        # 执行信号
        self.engine.on_signal(signal, ref_price=feature["mid_price"])

        # 更新账户
        self.ledger.update_balances()
        self.log(f"账户快照: {self.ledger.snapshot()}")

        # 记录历史
        self.history.append({
            "time": now_ts(),
            "feature": feature,
            "signal": signal,
            "probs": probs
        })

    def run_loop(self, interval=10, rounds=5):
        """
        连续运行多轮实盘逻辑
        """
        self.log("===== 启动实盘交易循环 =====")
        for i in range(rounds):
            self.log(f"—— 第 {i+1} 轮 ——")
            self.run_once()
            time.sleep(interval)
        self.log("===== 实盘交易结束 =====")
        self.log(f"日志文件保存于：{self.log_file}")

# ---------- 主程序入口 ----------
if __name__ == "__main__":
    # ⚠️ 在这里配置你的真实API密钥
    API_KEY = "你的API_KEY"
    API_SECRET = "你的API_SECRET"

    app = MetaReactionPredictorApp(API_KEY, API_SECRET)
    app.run_loop(interval=15, rounds=10)