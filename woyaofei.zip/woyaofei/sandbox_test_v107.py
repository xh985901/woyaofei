# -*- coding: utf-8 -*-
# sandbox_test_v107.py
# 模块：AI全局仓位锁防线系统（Global Position Lock & Risk Control）

import time
import random

class AIGlobalPositionLock:
    def __init__(self):
        # 全局仓位与风控参数
        self.total_position = 0.0     # 当前全局持仓百分比
        self.max_global_position = 0.30  # 全局锁死上限 30%
        self.max_single_coin = 0.15      # 单币锁死上限 15%
        self.cooldown_timer = 0          # 冷却倒计时（秒）
        self.last_order_time = 0         # 上次下单时间
        self.order_count_minute = 0      # 每分钟下单次数
        self.global_lock = False         # 全局锁定标志
        self.active_positions = {"BTCUSDT": 0.0, "ETHUSDT": 0.0, "SOLUSDT": 0.0}

    def approve_trade(self, symbol, ai_confidence, risk_index, order_size):
        """
        核心风控函数：检查是否允许下单
        """
        now = time.time()

        # 冷却机制触发：AI高频下单保护
        if now - self.last_order_time < 60:
            self.order_count_minute += 1
        else:
            self.order_count_minute = 1
            self.last_order_time = now

        if self.order_count_minute > 3:
            self.global_lock = True
            self.cooldown_timer = 600  # 冷却10分钟
            print(f"⚠️ 高频下单保护触发！系统已锁定10分钟冷却。")
            return False

        # 若全局锁开启，禁止下单
        if self.global_lock:
            print(f"🚫 系统锁定中({self.cooldown_timer}s)，禁止下单。")
            return False

        # 风险因子判断
        if ai_confidence < 0.60 or risk_index > 50:
            print(f"⚠️ 风控拒绝下单：信心({ai_confidence:.2f}) / 风险({risk_index:.2f}) 不达标。")
            return False

        # 仓位检测
        single_pos = self.active_positions.get(symbol, 0.0)
        if single_pos + order_size > self.max_single_coin:
            print(f"⛔ 仓位超限：{symbol} 当前={single_pos:.2%}，尝试={order_size:.2%}，超过上限15%。")
            return False

        if self.total_position + order_size > self.max_global_position:
            print(f"🚫 全局仓位超限：当前总仓={self.total_position:.2%}，最大允许={self.max_global_position:.2%}")
            return False

        # 一切正常 → 执行下单
        self.total_position += order_size
        self.active_positions[symbol] = single_pos + order_size
        print(f"✅ 批准下单：{symbol} | 仓位={order_size:.2%} | 总仓={self.total_position:.2%}")
        return True

    def release_position(self, symbol, close_size):
        """平仓释放仓位"""
        pos = self.active_positions.get(symbol, 0.0)
        release = min(pos, close_size)
        self.active_positions[symbol] = pos - release
        self.total_position -= release
        print(f"💨 平仓完成：{symbol} -{release:.2%} | 当前总仓={self.total_position:.2%}")

    def cooldown_tick(self):
        """冷却计时"""
        if self.global_lock and self.cooldown_timer > 0:
            self.cooldown_timer -= 10
            if self.cooldown_timer <= 0:
                self.global_lock = False
                print("✅ 冷却结束，系统恢复正常交易权限。")

# ------------------------------
# 模拟沙盒测试
if __name__ == "__main__":
    print("🚀 启动《我要飞合约版》v107 模块：AI全局仓位锁防线系统\n")
    ai_lock = AIGlobalPositionLock()

    test_cases = [
        ("BTCUSDT", 0.95, 20, 0.10),
        ("ETHUSDT", 0.92, 30, 0.12),
        ("SOLUSDT", 0.88, 40, 0.12),
        ("BTCUSDT", 0.90, 25, 0.05),  # 超出全局上限触发警告
        ("ETHUSDT", 0.70, 20, 0.02),
    ]

    for sym, conf, risk, size in test_cases:
        ai_lock.approve_trade(sym, conf, risk, size)
        time.sleep(1)

    print("\n🧩 模拟结束，触发风控冷却检测...")
    for _ in range(3):
        ai_lock.cooldown_tick()
        time.sleep(1)

    print("\n✅ 所有防线逻辑运行完毕，AI仓位保护系统已生效。")