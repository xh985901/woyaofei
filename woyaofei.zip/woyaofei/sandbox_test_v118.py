# ===========================================
sandbox_test_v118.py
# ===========================================

import time
import random
import statistics
import threading
from pathlib import Path

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class FastTradeMode:
    """
    实盘级快速撮合模式模块：
      - 模拟订单撮合与滑点计算
      - 可扩展接入真实撮合系统（预留接口）
      - 支持后台非阻塞执行
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("FastTradeMode")

        self.execution_records = []
        self.latency_records = []
        self.sim_count = 0
        self.lock = threading.Lock()

        self.logger.info("FastTradeMode 初始化完成")

    # ---------- 核心模拟 ----------
    def simulate_match(self, order_size: float, market_depth: float):
        """
        模拟单次撮合行为（可扩展为真实撮合接口）
        参数:
            order_size: 订单数量（例如 USDT）
            market_depth: 市场深度（可成交量）
        返回:
            延迟(ms)、滑点比例、执行价系数
        """
        with self.lock:
            base_latency = random.uniform(30, 100)  # 毫秒
            depth_factor = max(0.1, 1 - (order_size / (market_depth + 1e-9)))
            slip = (1 - depth_factor) * random.uniform(0.01, 0.05)

            exec_latency = round(base_latency * (1 + random.uniform(-0.1, 0.2)), 2)
            exec_price_factor = 1 - slip if random.random() > 0.5 else 1 + slip

            self.latency_records.append(exec_latency)
            self.execution_records.append(exec_price_factor)
            self.sim_count += 1

            self.logger.info(
                f"⚙️ 撮合 {self.sim_count} 次 | 延迟 {exec_latency} ms | 滑点 {slip*100:.2f}% | 执行系数 {exec_price_factor:.4f}"
            )
            return exec_latency, slip, exec_price_factor

    # ---------- 延迟评估 ----------
    def evaluate_speed(self):
        """统计撮合速度与稳定性"""
        if not self.latency_records:
            self.logger.warning("⚠️ 暂无撮合记录可评估")
            return None

        with self.lock:
            avg_latency = round(statistics.mean(self.latency_records), 2)
            jitter = round(statistics.stdev(self.latency_records), 2) if len(self.latency_records) > 1 else 0.0
            result = {"average_latency": avg_latency, "jitter": jitter}

            self.logger.info(f"📊 撮合延迟评估：平均 {avg_latency} ms | 波动 {jitter} ms")
            return result

    # ---------- 模拟任务 ----------
    def run_simulation(self, rounds=10, async_mode=False):
        """
        运行多轮撮合模拟（可异步）
        参数:
            rounds: 模拟轮数
            async_mode: 是否异步后台执行
        """
        def _runner():
            self.logger.info(f"🚀 启动快速撮合模拟，共 {rounds} 回合")
            for i in range(rounds):
                order_size = random.uniform(100, 500)
                depth = random.uniform(1000, 5000)
                self.simulate_match(order_size, depth)
                time.sleep(0.05)  # 控制速率，避免CPU占满
            self.evaluate_speed()

        if async_mode:
            t = threading.Thread(target=_runner, daemon=True)
            t.start()
            self.logger.info("🧩 撮合模拟已在后台运行")
        else:
            _runner()


# ---------- 独立运行 ----------
if __name__ == "__main__":
    f = FastTradeMode()
    f.run_simulation(rounds=15, async_mode=False)