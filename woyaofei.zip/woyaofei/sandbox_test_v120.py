# ===========================================
sandbox_test_v120.py
# ===========================================

import time
import random
import datetime
import threading
from pathlib import Path

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class AntiAIPattern:
    """
    实盘AI反检测伪装模块：
      - 为策略动作增加随机延迟与数量扰动；
      - 随机切换“人类式行为模式”；
      - 支持异步执行（不阻塞UI）；
      - 可在真实交易环境中启用，以降低被量化检测风险。
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("AntiAIPattern")

        report_dir = Path(self.cfg.get("report_dir"))
        report_dir.mkdir(parents=True, exist_ok=True)
        self.pattern_log = report_dir / "random_behavior_log.csv"

        self.random_seed = int(time.time())
        random.seed(self.random_seed)
        self.logger.info(f"🧩 伪装模块已启动 | 随机种子={self.random_seed}")

        self._async_lock = threading.Lock()

    # ---------- 延迟伪装 ----------
    def random_delay(self, base_delay: float = 1.0, async_mode: bool = False):
        """
        在操作前增加轻微随机延迟，模拟人类反应时间。
        参数:
            base_delay : 基础延迟（秒）
            async_mode : 若为 True，则在后台线程异步延迟执行
        """
        noise = random.uniform(-0.4, 0.6)
        final_delay = max(0, base_delay + noise)

        def _delay_task():
            self.logger.info(f"⏱️ 模拟人类犹豫：延迟 {final_delay:.2f} 秒")
            time.sleep(final_delay)

        if async_mode:
            t = threading.Thread(target=_delay_task, daemon=True)
            t.start()
        else:
            _delay_task()

        return final_delay

    # ---------- 下单扰动 ----------
    def random_order_variation(self, qty: float) -> float:
        """
        模拟下单数量的轻微波动，防止固定化特征。
        参数:
            qty : 原始下单数量
        返回:
            扰动后的数量
        """
        noise = random.uniform(-0.2, 0.2)
        adjusted_qty = round(qty * (1 + noise), 3)
        self.logger.info(f"📦 数量扰动：原 {qty:.3f} → 扰动后 {adjusted_qty:.3f}")
        return adjusted_qty

    # ---------- 模式切换 ----------
    def behavior_switch(self) -> str:
        """
        随机切换“行为模式”，模拟人类决策风格。
        """
        modes = ["积极模式", "稳健模式", "犹豫模式", "冷静模式"]
        mode = random.choice(modes)
        self.logger.info(f"🎭 模拟人类行为切换 → 当前模式：{mode}")
        return mode

    # ---------- 运行演示 ----------
    def run_simulation(self, rounds: int = 10, async_mode: bool = False):
        """
        执行多轮行为伪装模拟，可异步运行。
        参数:
            rounds : 模拟次数
            async_mode : 是否异步后台执行
        """

        def _simulate():
            self.logger.info(f"🚀 启动行为伪装模拟，共 {rounds} 轮")
            for i in range(rounds):
                delay = self.random_delay(0.8, async_mode=False)
                qty = random.uniform(0.5, 5)
                _ = self.random_order_variation(qty)
                _ = self.behavior_switch()
                with self._async_lock:
                    try:
                        with open(self.pattern_log, "a", encoding="utf-8") as f:
                            f.write(f"{datetime.datetime.now()},{delay:.2f},{qty:.3f}\n")
                    except Exception as e:
                        self.logger.error(f"⚠️ 写入伪装日志失败: {e}")
            self.logger.info("✅ 行为伪装模拟完成")

        if async_mode:
            threading.Thread(target=_simulate, daemon=True).start()
        else:
            _simulate()


# ---------- 独立运行 ----------
if __name__ == "__main__":
    ai = AntiAIPattern()
    ai.run_simulation(rounds=8, async_mode=False)