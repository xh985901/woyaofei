# ===========================================
sandbox_test_v119.py
# ===========================================

import os
import pandas as pd
import numpy as np
import datetime
from pathlib import Path

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class LiquidityFilter:
    """
    实盘流动性过滤模块：
      - 分析盘口深度（买卖挂单量）与价差
      - 计算综合流动性得分
      - 输出报告 CSV，可供监控系统或可视化调用
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("LiquidityFilter")

        self.data_dir = Path(self.cfg.get("data_dir"))
        self.report_dir = Path(self.cfg.get("report_dir"))
        self.report_dir.mkdir(parents=True, exist_ok=True)

        self.threshold_depth = 100000   # 最低流动性阈值
        self.slippage_limit = 0.005     # 最大价差 0.5%

        self.filter_report = self.report_dir / "liquidity_report.csv"

        self.logger.info("LiquidityFilter 初始化完成", {
            "data_dir": str(self.data_dir),
            "report_path": str(self.filter_report)
        })

    # ---------- 核心评估 ----------
    def evaluate_liquidity(self, df: pd.DataFrame) -> dict | None:
        """
        流动性评估：
          输入 DataFrame（必须包含 bid_vol、ask_vol、spread）
          输出 dict {ok_ratio, avg_score, timestamp}
        """
        required = ["bid_vol", "ask_vol", "spread"]
        for col in required:
            if col not in df.columns:
                self.logger.error(f"❌ 数据缺少必要列：{col}")
                return None

        df = df.copy()
        df["total_depth"] = df["bid_vol"] + df["ask_vol"]
        df["depth_ok"] = df["total_depth"] > self.threshold_depth
        df["slippage_ok"] = df["spread"] < self.slippage_limit

        # 综合得分计算
        df["liquidity_score"] = (
            (df["total_depth"] / self.threshold_depth).clip(0, 2) * 0.6 +
            (1 - df["spread"] / self.slippage_limit).clip(0, 1) * 0.4
        )
        df["liquidity_score"] = df["liquidity_score"].clip(0, 1)

        ok_ratio = round((df["liquidity_score"] > 0.7).sum() / len(df), 3)
        avg_score = round(df["liquidity_score"].mean(), 3)

        result = {
            "ok_ratio": ok_ratio,
            "avg_score": avg_score,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        try:
            df.to_csv(self.filter_report, index=False, encoding="utf-8-sig")
            self.logger.info(f"✅ 流动性评估完成：平均得分 {avg_score:.3f}，合格率 {ok_ratio*100:.1f}%")
        except Exception as e:
            self.logger.error(f"写入流动性报告失败: {e}")

        return result

    # ---------- 加载数据 ----------
    def load_sample_data(self) -> pd.DataFrame:
        """
        若无真实盘口文件，则自动生成模拟样本
        """
        sample_path = self.data_dir / "sample_depth.csv"
        if not sample_path.exists():
            self.logger.warning(f"⚠️ 未找到 {sample_path}，自动生成模拟数据...")
            np.random.seed(42)
            df = pd.DataFrame({
                "bid_vol": np.random.randint(50000, 200000, 50),
                "ask_vol": np.random.randint(50000, 200000, 50),
                "spread": np.random.uniform(0.001, 0.01, 50)
            })
            try:
                sample_path.parent.mkdir(parents=True, exist_ok=True)
                df.to_csv(sample_path, index=False)
                self.logger.info(f"✅ 模拟数据已生成: {sample_path}")
            except Exception as e:
                self.logger.error(f"保存模拟数据失败: {e}")

        try:
            df = pd.read_csv(sample_path)
            return df
        except Exception as e:
            self.logger.error(f"加载数据失败: {e}")
            return pd.DataFrame(columns=["bid_vol", "ask_vol", "spread"])


# ---------- 独立执行 ----------
if __name__ == "__main__":
    lf = LiquidityFilter()
    df = lf.load_sample_data()
    result = lf.evaluate_liquidity(df)
    if result:
        print("流动性检测结果:", result)