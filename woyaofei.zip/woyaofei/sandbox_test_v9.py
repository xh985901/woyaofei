"""
《我要飞合约版》v10 实盘沙盒整合源码 - 第四段
模块范围：#19 ~ #20
功能：趋势波动 + 异常波动一体化核心大脑、软件防骗逻辑、总调度入口。
"""

import random, time
from datetime import datetime
import pytz

def log(msg):
    now = datetime.now(pytz.timezone("Asia/Shanghai")).strftime("[%Y-%m-%d %H:%M:%S]")
    print(f"{now} {msg}")

# =============== 模块19：趋势波动 + 异常波动一体化模块 ===============
class TrendAndVolatilityCore:
    """融合趋势与异常波动决策"""
    def __init__(self):
        self.threshold_pct = 1.5
        self.trend_strength = 0
        self.last_signal = None

    def predict_volatility(self, prices):
        """预测波动率（简单模拟）"""
        change = (prices[-1] - prices[0]) / prices[0] * 100
        conf = min(abs(change) / self.threshold_pct * 50, 95)
        decision = "多头" if change > 0 else "空头"
        log(f"📈 预测波动：{change:.2f}% → {decision}（置信度 {conf:.1f}%）")
        return {"change": change, "decision": decision, "confidence": conf}

    def detect_trend(self, k_lines):
        """检测连续K线趋势"""
        ups = sum(1 for k in k_lines if k > 0)
        downs = len(k_lines) - ups
        if ups > downs + 1:
            self.trend_strength = ups / len(k_lines)
            log(f"📊 检测到上升趋势（强度 {self.trend_strength:.2f}）")
            return "多头"
        elif downs > ups + 1:
            self.trend_strength = downs / len(k_lines)
            log(f"📊 检测到下降趋势（强度 {self.trend_strength:.2f}）")
            return "空头"
        else:
            log("😐 趋势不明显，保持观望")
            return "观望"

    def make_decision(self, prices, k_lines):
        """综合判断"""
        vola = self.predict_volatility(prices)
        trend = self.detect_trend(k_lines)
        conf = (vola["confidence"] + self.trend_strength * 100) / 2
        if conf >= 70:
            signal = vola["decision"]
            log(f"✅ 触发决策信号：{signal}（综合置信度 {conf:.1f}%）")
        else:
            signal = "观望"
            log(f"⚠️ 信号不足，暂不执行（置信度 {conf:.1f}%）")
        self.last_signal = signal
        return signal

# =============== 模块20：软件防骗逻辑（回马枪应对） ===============
class AntiTrapDefense:
    """识别诱多/诱空，防止回马枪行情"""
    def __init__(self):
        self.last_direction = None
        self.trap_count = 0

    def analyze(self, volume, fake_order_detected):
        if volume > 1.5 and fake_order_detected:
            self.trap_count += 1
            log("🚨 检测到疑似回马枪诱单，暂停操作 1 根K线")
            return False
        return True

    def respond(self, signal):
        if self.last_direction and self.last_direction != signal and signal != "观望":
            log(f"⚔️ 回马枪应对：反向信号出现（{self.last_direction}→{signal}），触发止损并反手！")
        self.last_direction = signal

# =============== 模拟实盘沙盒入口（全模块联动） ===============
if __name__ == "__main__":
    log("🔥 启动核心大脑沙盒测试（模块19~20）")

    core = TrendAndVolatilityCore()
    defense = AntiTrapDefense()

    # 模拟数据
    prices = [100, 101.5, 102.3, 103.2, 104.8]
    k_lines = [1, 1, 1, -1, 1]
    fake_detect = random.choice([True, False])
    vol = random.uniform(1.0, 2.0)

    signal = core.make_decision(prices, k_lines)
    safe = defense.analyze(vol, fake_detect)
    if safe:
        defense.respond(signal)

    log("✅ 模块19~20 测试完成")
    log("🧩 所有模块沙盒阶段已全部跑通")