# -*- coding: utf-8 -*-
"""
🔥 《我要飞合约版》v15 实盘监控稳定性回测引擎
📅 北京时间自动记录版
功能：
1. 连续监控币安三大币种（BTC、ETH、SOL）
2. 每轮间隔2秒，共30轮检测
3. 自动计算延迟、波动率、异常次数
4. 输出稳定性评分并保存报告
"""

import requests
import time
from datetime import datetime

# === 基础设置 ===
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
URL = "https://api.binance.com/api/v3/ticker/24hr"
DELAY_LIMIT = 2000       # 毫秒阈值
FLUCT_LIMIT = 0.01       # 价格波动阈值 1%
ROUND_COUNT = 30
INTERVAL = 2             # 每轮间隔秒数

# === 记录变量 ===
prices = {coin: None for coin in COINS}
delays = []
fluct_count = 0
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

print(f"[{start_time}] 🚀 启动《我要飞合约版》v15 实盘监控稳定性回测引擎\n")

for i in range(1, ROUND_COUNT + 1):
    round_start = time.time()
    print(f"第 {i}/30 轮实时检测……")

    for coin in COINS:
        try:
            t0 = time.time()
            res = requests.get(URL, params={"symbol": coin}, timeout=5)
            delay = (time.time() - t0) * 1000  # 转毫秒
            data = res.json()

            if "lastPrice" in data:
                price = float(data["lastPrice"])
                old_price = prices[coin]
                prices[coin] = price

                if old_price:
                    diff = abs(price - old_price) / old_price
                    if diff > FLUCT_LIMIT:
                        fluct_count += 1
                        print(f"⚠️ [{coin}] 波动异常：{diff*100:.2f}%")

                status = "✅" if delay < DELAY_LIMIT else "⚠️ 延迟过高"
                print(f"  📊 {coin} 价 {price} USDT | 延迟 {delay:.1f} ms {status}")
                delays.append(delay)
            else:
                print(f"❌ {coin} 返回异常：{data}")

        except Exception as e:
            print(f"❌ {coin} 获取失败：{e}")

    time.sleep(INTERVAL)

# === 计算结果 ===
avg_delay = sum(delays) / len(delays) if delays else 0
stable_score = max(0, 100 - (fluct_count * 1.5 + avg_delay / 50))
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# === 输出汇总 ===
print("\n" + "=" * 60)
print(f"📅 测试开始：{start_time}")
print(f"📅 测试结束：{end_time}")
print(f"📊 平均延迟：{avg_delay:.1f} ms")
print(f"📈 异常波动次数：{fluct_count}")
print(f"🏁 系统稳定性评分：{stable_score:.2f} / 100")
print("=" * 60)

# === 保存报告 ===
report_name = "report_stable_v15.txt"
with open(report_name, "w", encoding="utf-8") as f:
    f.write(f"《我要飞合约版》v15 实盘监控报告\n")
    f.write(f"开始时间: {start_time}\n")
    f.write(f"结束时间: {end_time}\n")
    f.write(f"平均延迟: {avg_delay:.1f} ms\n")
    f.write(f"异常波动次数: {fluct_count}\n")
    f.write(f"系统稳定性评分: {stable_score:.2f} / 100\n")

print(f"📁 报告已保存为 {report_name}")
print("✅ v15 稳定性回测完毕，系统运行正常。\n")