# ======================================================
# 模块16: 网络链路健康检测 (NetworkHealthMonitor)
# 功能: 持续检测延迟、丢包、线路健康；异常时自动降级或切换备用线路。
# ======================================================

import random
import time
import datetime

class NetworkHealthMonitor:
    def __init__(self):
        self.main_line = "Primary"
        self.backup_line = "Backup"
        self.current_line = self.main_line
        self.status = "NORMAL"
        self.latency = 0
        self.loss_rate = 0.0

    def ping(self):
        """模拟ping测试"""
        self.latency = random.randint(40, 1200)
        self.loss_rate = random.random() * 0.25
        print(f"📡 Ping延迟={self.latency}ms 丢包率={self.loss_rate:.2%}")

    def evaluate(self):
        """评估网络状态"""
        if self.latency > 800 or self.loss_rate > 0.15:
            self.status = "DEGRADED"
            print("⚠️ 网络性能下降，准备切换备用线路…")
            self.switch_to_backup()
        else:
            self.status = "NORMAL"

    def switch_to_backup(self):
        """切换至备用线路"""
        self.current_line = self.backup_line
        print(f"↩️ 已切换至备用线路: {self.current_line}")

    def recover_main(self):
        """恢复主线路"""
        if self.current_line != self.main_line:
            print("✅ 主线路恢复，切回主线。")
            self.current_line = self.main_line
            self.status = "NORMAL"

    def monitor_loop(self, rounds=3):
        """连续检测循环"""
        for _ in range(rounds):
            self.ping()
            self.evaluate()
            time.sleep(1)
        print(f"🌐 当前使用线路: {self.current_line} 状态: {self.status}")


# ======================================================
# 模块17: 异常订单兜底逻辑 (OrderRecovery)
# 功能: 订单提交后若长时间无回报，自动查询状态并处理重复/漏单。
# ======================================================

class OrderRecovery:
    def __init__(self):
        self.pending_orders = {}
        self.recovered_orders = []

    def submit_order(self, order_id):
        """模拟提交订单"""
        self.pending_orders[order_id] = {
            "submitted": datetime.datetime.now(),
            "status": "PENDING"
        }
        print(f"📩 提交订单 {order_id}")

    def check_orders(self):
        """检查超时订单"""
        now = datetime.datetime.now()
        for order_id, info in list(self.pending_orders.items()):
            seconds = (now - info["submitted"]).seconds
            if seconds > 5:
                if random.random() > 0.5:
                    print(f"✅ 订单 {order_id} 已在交易所成交。")
                    info["status"] = "FILLED"
                else:
                    print(f"⚠️ 订单 {order_id} 超时无回报，自动追查中…")
                    info["status"] = "RECOVERED"
                self.recovered_orders.append(order_id)
                del self.pending_orders[order_id]

    def summary(self):
        """打印订单状态总结"""
        print(f"📋 当前待处理订单数: {len(self.pending_orders)}")
        print(f"♻️ 已恢复订单: {self.recovered_orders}")


# ======================================================
# 模块18: 资金与风险保护 (RiskLimitControl)
# 功能: 控制总仓位上限、单笔风险比例、黑名单币种、交易时间限制。
# ======================================================

class RiskLimitControl:
    def __init__(self, max_total_position_ratio=0.5, max_single_trade_ratio=0.2):
        self.max_total_position_ratio = max_total_position_ratio
        self.max_single_trade_ratio = max_single_trade_ratio
        self.blacklist = ["PEPEUSDT", "LUNAUSDT"]
        self.active_positions = {}
        self.trading_hours = (0, 24)

    def can_trade(self, symbol, size, balance):
        """是否允许开仓"""
        now = datetime.datetime.now().hour
        if symbol in self.blacklist:
            print(f"🚫 {symbol} 在黑名单中，禁止交易。")
            return False
        if not (self.trading_hours[0] <= now < self.trading_hours[1]):
            print("⏰ 当前非交易时段。")
            return False

        total_position = sum(self.active_positions.values()) / balance if balance > 0 else 0
        if total_position + size / balance > self.max_total_position_ratio:
            print("⚠️ 总仓位超限，拒绝开仓。")
            return False

        if size / balance > self.max_single_trade_ratio:
            print("⚠️ 单笔仓位比例过高，拒绝开仓。")
            return False

        print(f"✅ 符合风控要求，可交易 {symbol}")
        return True

    def open_position(self, symbol, size):
        """记录持仓"""
        self.active_positions[symbol] = self.active_positions.get(symbol, 0) + size
        print(f"📊 开仓 {symbol} {size}")

    def close_position(self, symbol):
        """平仓"""
        if symbol in self.active_positions:
            print(f"💰 平仓 {symbol}, 释放资金。")
            del self.active_positions[symbol]
if __name__ == "__main__":
    print("🚀 模块16-18 综合测试开始...\n")

    # 测试模块16：网络链路健康检测
    nhm = NetworkHealthMonitor()
    nhm.monitor_loop(rounds=3)

    # 测试模块17：异常订单兜底逻辑
    orc = OrderRecovery()
    orc.submit_order("A001")
    time.sleep(6)
    orc.check_orders()
    orc.summary()

    # 测试模块18：资金与风险保护
    risk = RiskLimitControl()
    balance = 10000
    print("\n尝试开仓 BTCUSDT ...")
    if risk.can_trade("BTCUSDT", 1500, balance):
        risk.open_position("BTCUSDT", 1500)
    print("\n尝试开仓 PEPEUSDT (黑名单)...")
    risk.can_trade("PEPEUSDT", 500, balance)
    risk.close_position("BTCUSDT")

    print("\n🎯 模块16-18 综合测试完毕。")