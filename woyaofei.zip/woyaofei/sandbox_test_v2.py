# ===============================================================
# 模块19：趋势波动 + 异常波动一体化模块（DecisionEngine）
# 功能：识别未来30–45分钟内的异常波动信号与趋势信号；
#       优先执行异常波动策略（狙击手），否则执行趋势策略（步兵连）。
# ===============================================================

import random
import datetime
import time


class DecisionEngine:
    def __init__(self):
        self.last_decision_time = None
        self.cooldown_minutes = 10
        self.tracked_symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

    def predict_volatility(self, price_series):
        """预测未来波动（模拟模型输出）"""
        expected_change = random.uniform(-2.0, 2.0)
        confidence = random.uniform(0.4, 0.95)
        return expected_change, confidence

    def detect_trend(self, price_series):
        """简单趋势检测"""
        if len(price_series) < 3:
            return "neutral"
        if price_series[-1] > price_series[-3]:
            return "up"
        elif price_series[-1] < price_series[-3]:
            return "down"
        else:
            return "neutral"

    def decide(self, symbol, price_series):
        """核心决策逻辑"""
        now = datetime.datetime.now()
        if self.last_decision_time and (now - self.last_decision_time).seconds < self.cooldown_minutes * 60:
            return {"symbol": symbol, "action": "wait", "reason": "cooldown中", "confidence": 0.0}

        expected_change, conf = self.predict_volatility(price_series)
        trend = self.detect_trend(price_series)

        if abs(expected_change) >= 1.5 and conf >= 0.75:
            action = "buy" if expected_change > 0 else "sell"
            reason = "异常波动预警（狙击手）"
        elif trend != "neutral":
            action = "buy" if trend == "up" else "sell"
            reason = "趋势跟随（步兵连）"
        else:
            action = "wait"
            reason = "无明显信号"

        self.last_decision_time = now
        print(f"🤖 {symbol}: {reason} | 动作={action} | 置信度={conf:.2f}")
        return {"symbol": symbol, "action": action, "confidence": conf, "reason": reason}

    def multi_symbol_decide(self, market_data):
        """支持多币种决策"""
        results = []
        for symbol, series in market_data.items():
            res = self.decide(symbol, series)
            results.append(res)
        return results


# ===============================================================
# 模块20：软件防骗逻辑（AntiManipulationGuard）
# 功能：识别诱多/诱空、假突破、“回马枪”等陷阱；
#       检测成交量激增 + 挂单异常 + 时间确认 三重条件。
# ===============================================================

class AntiManipulationGuard:
    def __init__(self):
        self.last_trigger = None
        self.trigger_cooldown = 5  # 分钟
        self.confirmation_required = 2  # 连续确认次数
        self.warning_active = False

    def detect_fake_move(self, price_series, volume_series):
        """识别假突破或诱单"""
        if len(price_series) < 3:
            return False
        price_up = price_series[-1] > price_series[-2] > price_series[-3]
        volume_spike = volume_series[-1] > volume_series[-2] * 1.8
        return price_up and volume_spike

    def confirm_direction(self, direction_series):
        """方向持续确认"""
        if len(direction_series) < self.confirmation_required:
            return False
        return all(d == direction_series[0] for d in direction_series[-self.confirmation_required:])

    def evaluate_market(self, price_series, volume_series, direction_series):
        """综合判定"""
        fake_move = self.detect_fake_move(price_series, volume_series)
        sustained = self.confirm_direction(direction_series)

        if fake_move and sustained:
            if not self.warning_active:
                self.warning_active = True
                self.last_trigger = time.time()
                print("⚠️ 检测到假突破或诱多陷阱！")
            else:
                print("🚨 警告持续中，请勿追单。")
            return {"trap": True, "action": "wait"}
        else:
            if self.warning_active and time.time() - self.last_trigger > self.trigger_cooldown * 60:
                print("✅ 风险解除，恢复正常交易。")
                self.warning_active = False
            return {"trap": False, "action": "ok"}

    def react_to_trap(self):
        """触发反手机制"""
        if self.warning_active:
            print("↩️ 触发反手策略：先止损，后小仓反向进场。")


# ===============================================================
# 测试入口
# ===============================================================

if __name__ == "__main__":
    print("🚀 模块19–20 联合测试启动中...\n")

    # 初始化模块
    dec = DecisionEngine()
    guard = AntiManipulationGuard()

    # 模拟行情数据
    fake_prices = {
        "BTCUSDT": [100, 101, 102, 104, 103],
        "ETHUSDT": [200, 198, 197, 199, 201],
        "SOLUSDT": [30, 31, 32, 33, 32],
    }
    fake_volumes = [1000, 1100, 1800, 3300, 6000]
    directions = ["up", "up", "up"]

    # 执行趋势/波动决策
    results = dec.multi_symbol_decide(fake_prices)

    print("\n📊 一体化策略输出结果：")
    for r in results:
        conf = r.get("confidence", 0.0)
        print(f"→ {r['symbol']} | 动作={r['action']} | 原因={r['reason']} | 置信度={conf:.2f}")

    print("\n🧩 正在检测防骗模块...")
    result_guard = guard.evaluate_market(
        fake_prices["BTCUSDT"], fake_volumes, directions
    )

    print(f"🛡️ 防骗模块输出：{result_guard}")
    guard.react_to_trap()

    print("\n✅ 模块19–20 测试完毕。")