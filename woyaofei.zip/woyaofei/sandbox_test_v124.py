# ===========================================
sandbox_test_v124.py
# ===========================================

import numpy as np
import pandas as pd
from pathlib import Path

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class MetaStrategyBlender:
    """
    实盘多策略融合模块：
      - 集成动量、均值回归、成交量突发三种基础策略；
      - 通过加权投票生成综合交易信号；
      - 使用强化学习规则调整策略权重；
      - 可无缝嵌入 Android BeeWare 实盘 APK 环境。
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("MetaStrategyBlender")

        self.report_dir = Path(self.cfg.get("report_dir"))
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.report_path = self.report_dir / "meta_strategy_blend_report.csv"

        # 策略池定义（真实环境下可扩展为自定义策略）
        self.strategies = {
            "momentum": self.strategy_momentum,
            "mean_revert": self.strategy_mean_revert,
            "volume_spike": self.strategy_volume_spike,
        }

        # 初始权重与学习率
        self.weights = {name: 1 / len(self.strategies) for name in self.strategies}
        self.learning_rate = 0.05

        self.logger.info("MetaStrategyBlender 初始化完成", {
            "strategies": list(self.strategies.keys()),
            "learning_rate": self.learning_rate
        })

    # ---------- 策略函数 ----------
    def strategy_momentum(self, data: pd.DataFrame) -> int:
        """动量策略：若整体涨幅为正 → 做多"""
        signal = np.sign(data["price_change"].mean())
        return int(signal)

    def strategy_mean_revert(self, data: pd.DataFrame) -> int:
        """均值回归策略：价格急涨则做空"""
        signal = -np.sign(data["price_change"].iloc[-1])
        return int(signal)

    def strategy_volume_spike(self, data: pd.DataFrame) -> int:
        """成交量突发策略：成交量激增 → 看涨"""
        vol_mean = data["volume"].mean()
        signal = 1 if data["volume"].iloc[-1] > vol_mean * 1.5 else -1
        return int(signal)

    # ---------- 数据生成 ----------
    def simulate_market_data(self, n: int = 200) -> pd.DataFrame:
        """
        生成测试用市场数据（实盘中应替换为真实行情数据）。
        """
        np.random.seed(42)
        df = pd.DataFrame({
            "price_change": np.random.normal(0, 0.002, n),
            "volume": np.random.uniform(100, 500, n)
        })
        return df

    # ---------- 策略融合 ----------
    def blend_strategies(self, data: pd.DataFrame):
        """
        执行策略融合计算：根据各策略信号 × 权重 求出综合信号。
        返回 (final_signal, signals_dict)
        """
        signals = {name: func(data) for name, func in self.strategies.items()}
        weighted_sum = sum(self.weights[name] * signals[name] for name in self.strategies)
        final_signal = int(np.sign(weighted_sum)) if weighted_sum != 0 else 0

        self.logger.info("融合信号计算完成", {
            "signals": signals,
            "weights": self.weights,
            "final_signal": final_signal
        })
        return final_signal, signals

    # ---------- 权重更新 ----------
    def update_weights(self, reward: float, signals: dict):
        """
        使用强化学习方式更新各策略权重。
        reward > 0 → 提升对应策略的影响力。
        """
        for name in self.weights:
            self.weights[name] += self.learning_rate * reward * signals[name]
            self.weights[name] = max(0.01, min(1, self.weights[name]))

        # 归一化
        total_w = sum(self.weights.values())
        for name in self.weights:
            self.weights[name] /= total_w

        self.logger.info("权重已更新", {"updated_weights": self.weights})

    # ---------- 主流程 ----------
    def run_analysis(self) -> float:
        """
        执行融合策略分析与模拟回测。
        可在实盘系统中定期执行以优化权重。
        """
        df = self.simulate_market_data()
        balance = 10000.0
        pnl_history = []

        for i in range(10, len(df), 10):
            subset = df.iloc[:i]
            final_signal, signals = self.blend_strategies(subset)

            # 模拟收益：信号方向 × 实际涨跌
            reward = np.sign(subset["price_change"].iloc[-1]) * final_signal
            balance += reward * 10.0
            self.update_weights(reward, signals)
            pnl_history.append(balance)

        result = pd.DataFrame({
            "step": range(len(pnl_history)),
            "balance": pnl_history
        })

        try:
            result.to_csv(self.report_path, encoding="utf-8-sig", index=False)
            self.logger.info(f"报告已保存：{self.report_path}")
        except Exception as e:
            self.logger.error(f"写入报告失败: {e}")

        self.logger.info(f"融合策略执行完成，最终收益: {balance:.2f} USDT")
        return balance


# ---------- 独立运行 ----------
if __name__ == "__main__":
    msb = MetaStrategyBlender()
    msb.run_analysis()