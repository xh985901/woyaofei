# ===========================================
sandbox_test_v123.py
# ===========================================

import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from pathlib import Path

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class ReverseModelTracer:
    """
    实盘AI行为追踪模块：
      - 通过微试探订单分析市场反馈；
      - 使用逻辑回归模型评估潜在AI对手响应模式；
      - 可嵌入实时交易系统用于模型调优与反检测分析。
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("ReverseModelTracer")

        self.data_dir = Path(self.cfg.get("data_dir"))
        self.report_dir = Path(self.cfg.get("report_dir"))
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.report_path = self.report_dir / "reverse_model_trace_report.csv"

        # 初始化模型
        self.model = LogisticRegression(max_iter=300, solver="lbfgs")
        self.logger.info("ReverseModelTracer 初始化完成", {
            "data_dir": str(self.data_dir),
            "report_path": str(self.report_path)
        })

    # ---------- 生成探测数据 ----------
    def generate_probe_data(self, n: int = 200) -> pd.DataFrame:
        """
        自动生成随机“微试探”数据。
        在实盘环境中，此部分可替换为真实订单反馈样本。
        """
        np.random.seed(42)
        df = pd.DataFrame({
            "test_order_size": np.random.uniform(0.1, 1.0, n),
            "response_time": np.random.uniform(0.01, 0.3, n),
            "slippage": np.random.uniform(0, 0.02, n),
            "depth_feedback": np.random.uniform(-0.4, 0.4, n),
        })
        df["label"] = np.where(
            (df["response_time"] < 0.1) & (df["slippage"] < 0.01),
            "AI对手反应",
            "普通撮合"
        )
        self.logger.info(f"🧪 已生成 {n} 条探测样本数据")
        return df

    # ---------- 模型训练 ----------
    def train_reverse_model(self, df: pd.DataFrame) -> float:
        """
        使用逻辑回归对样本进行分类学习。
        返回识别准确率。
        """
        if df.empty:
            self.logger.warning("⚠️ 样本为空，无法训练模型")
            return 0.0

        X = df[["test_order_size", "response_time", "slippage", "depth_feedback"]]
        y = (df["label"] == "AI对手反应").astype(int)

        try:
            self.model.fit(X, y)
            preds = self.model.predict(X)
            report = classification_report(y, preds, output_dict=True)
            pd.DataFrame(report).T.to_csv(self.report_path, encoding="utf-8-sig")
            acc = report.get("accuracy", 0)
            self.logger.info(f"📈 模型训练完成，识别准确率 {acc*100:.2f}%")
            return acc
        except Exception as e:
            self.logger.error(f"模型训练异常: {e}")
            return 0.0

    # ---------- 反向追踪 ----------
    def probe_and_trace(self) -> dict:
        """
        执行完整反向分析流程：
          生成 → 训练 → 计算特征重要性。
        """
        df = self.generate_probe_data()
        acc = self.train_reverse_model(df)
        if acc <= 0:
            self.logger.warning("⚠️ 模型训练失败，跳过特征分析")
            return {}

        try:
            importance = abs(self.model.coef_[0])
            features = ["test_order_size", "response_time", "slippage", "depth_feedback"]
            weights = dict(zip(features, importance))
            sorted_weights = dict(sorted(weights.items(), key=lambda x: x[1], reverse=True))
            self.logger.info(f"🧠 推测AI关键特征影响力: {sorted_weights}")
            return sorted_weights
        except Exception as e:
            self.logger.error(f"特征分析失败: {e}")
            return {}

    # ---------- 主流程 ----------
    def run_analysis(self):
        """
        启动实盘AI对手追踪分析。
        """
        self.logger.info("🚀 启动实盘反向模型追踪")
        result = self.probe_and_trace()
        self.logger.info(f"✅ 反向追踪完成，AI特征重要性: {result}")


# ---------- 独立执行 ----------
if __name__ == "__main__":
    rmt = ReverseModelTracer()
    rmt.run_analysis()