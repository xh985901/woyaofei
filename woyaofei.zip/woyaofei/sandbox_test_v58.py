# 🚀《我要飞合约版》v58 AI资金流追踪 + 盘口异动雷达系统
# -*- coding: utf-8 -*-
import requests, time, random
from datetime import datetime

api_url = "https://api.binance.com/api/v3/ticker/price"
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        r = requests.get(api_url, params={"symbol": symbol}, timeout=5)
        return float(r.json()["price"])
    except:
        return None

def 模拟盘口数据():
    """模拟盘口量能变化（实际可对接币安深度数据）"""
    主买 = random.uniform(40, 60)
    主卖 = 100 - 主买
    异动 = abs(主买 - 50)
    return 主买, 主卖, 异动

def 模拟资金流():
    """模拟主力资金净流入比例（%）"""
    return round(random.uniform(-2.5, 2.5), 2)

def 解读异动(资金流, 异动):
    """AI判断主力行为"""
    if 资金流 > 1.2 and 异动 > 5:
        return "主力吸筹", "⚠️ 潜在上涨准备"
    elif 资金流 < -1.2 and 异动 > 5:
        return "主力出货", "🚨 潜在下跌风险"
    elif abs(资金流) < 0.5 and 异动 > 4:
        return "震荡洗盘", "⚠️ 方向未定"
    else:
        return "正常波动", "✅ 无异常"

def 计算信心(资金流, 异动):
    """AI信心指数（%）"""
    信心 = 100 - abs(资金流 * 10) - 异动
    return max(50, min(信心, 100))

print(f"{获取时间()} 🚀 启动《我要飞合约版》v58 AI资金流追踪 + 盘口异动雷达系统\n")

while True:
    print("="*90)
    for s in symbols:
        当前价 = 获取币价(s)
        if not 当前价:
            print(f"⚠️ {s} 获取失败，跳过。")
            continue

        主买, 主卖, 异动 = 模拟盘口数据()
        资金流 = 模拟资金流()
        行为, 提示 = 解读异动(资金流, 异动)
        信心 = 计算信心(资金流, 异动)

        print(f"{获取时间()} {s} 当前价：{当前价:.2f} USDT")
        print(f"💧 主买占比：{主买:.1f}% | 主卖占比：{主卖:.1f}% | 异动强度：{异动:.2f}%")
        print(f"📊 主力净资金流：{资金流:+.2f}% | 行为：{行为} | 提示：{提示}")
        print(f"🧠 AI信心指数：{信心:.1f}%")
        if abs(资金流) > 1.5 or 异动 > 6:
            print(f"🚨【预警】{s} 出现强异动信号！建议重点关注！")
        print("-"*90)

    print("系统稳定运行中，AI异动雷达持续监测...\n")
    time.sleep(10)