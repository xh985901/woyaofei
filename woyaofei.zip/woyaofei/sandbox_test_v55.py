# 🚀《我要飞合约版》v55 情绪热度捕捉 + 记忆权重融合系统
# -*- coding: utf-8 -*-
import requests, time, random
from datetime import datetime
from collections import deque

api_url = "https://api.binance.com/api/v3/ticker/price"
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

采样间隔 = 8
记忆长度 = 12

价格记忆 = {s: deque(maxlen=记忆长度) for s in symbols}
预测记忆 = {s: deque(maxlen=记忆长度) for s in symbols}
AI记忆权重 = {s: 1.0 for s in symbols}
情绪指数 = {s: 0.0 for s in symbols}

def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        r = requests.get(api_url, params={"symbol": symbol}, timeout=5)
        return float(r.json()["price"])
    except:
        return None

def 波动计算(prices):
    if len(prices) < 2: return 0
    return (prices[-1] - prices[-2]) / prices[-2] * 100

def 计算情绪(symbol, prices):
    if len(prices) < 3: return "冷静", 0.0
    recent_changes = [(prices[i] - prices[i - 1]) / prices[i - 1] * 100 for i in range(1, len(prices))]
    活跃度 = sum(abs(c) for c in recent_changes[-5:]) / 5
    连续方向 = sum(1 if c > 0 else -1 for c in recent_changes[-5:])
    情绪 = 活跃度 + abs(连续方向) * 0.2

    if 情绪 < 0.3:
        状态 = "冷静"
    elif 情绪 < 0.8:
        状态 = "观望"
    elif 情绪 < 1.5:
        状态 = "活跃"
    else:
        状态 = "过热"

    return 状态, 情绪

def AI预测(symbol, prices):
    if len(prices) < 4: return 0
    seq = [(prices[i] - prices[i-1]) / prices[i-1] * 100 for i in range(1, len(prices))]
    base = sum(seq[-4:]) / 4
    noise = random.uniform(-0.03, 0.03)
    return base + noise

def 生成信号(symbol, 当前价):
    状态, 热度 = 计算情绪(symbol, 价格记忆[symbol])
    预测 = AI预测(symbol, 价格记忆[symbol])

    # 加入AI短期记忆修正
    if len(预测记忆[symbol]) > 3:
        历史均值 = sum(预测记忆[symbol]) / len(预测记忆[symbol])
        修正预测 = (预测 * 0.7 + 历史均值 * 0.3) * AI记忆权重[symbol]
    else:
        修正预测 = 预测

    # 计算把握度与风险
    把握度 = min(100, abs(修正预测) * random.uniform(90, 120))
    风险 = "高" if abs(修正预测) > 1.5 else "中" if abs(修正预测) > 0.5 else "低"
    稳定度 = max(70, 100 - abs(修正预测) * 20)
    AI信心 = min(100, 95 + random.uniform(-3, 3))

    # 情绪调整（过热→降信心；冷静→升信心）
    if 状态 == "过热":
        把握度 *= 0.85
    elif 状态 == "冷静":
        把握度 *= 1.1

    if 把握度 < 40:
        建议 = "观望"
    elif 把握度 < 70:
        建议 = "轻仓"
    elif 把握度 < 85:
        建议 = "中仓"
    else:
        建议 = "重仓"

    止盈 = 当前价 * (1.008 if 修正预测 > 0 else 0.992)
    止损 = 当前价 * (0.992 if 修正预测 > 0 else 1.008)

    # 更新记忆
    预测记忆[symbol].append(修正预测)
    情绪指数[symbol] = 热度
    return 状态, 热度, 把握度, 风险, 稳定度, AI信心, 建议, 修正预测, 止盈, 止损

print(f"{获取时间()} 🚀 启动《我要飞合约版》v55 情绪热度捕捉 + 记忆权重融合系统\n")

while True:
    print("="*75)
    for s in symbols:
        当前价 = 获取币价(s)
        if not 当前价:
            print(f"⚠️ {s} 数据获取失败，跳过。")
            continue

        价格记忆[s].append(当前价)
        if len(价格记忆[s]) < 3:
            continue

        状态, 热度, 把握度, 风险, 稳定度, AI信心, 建议, 修正预测, 止盈, 止损 = 生成信号(s, 当前价)
        print(f"{获取时间()} {s} 当前价：{当前价:.2f} USDT | 情绪：{状态} ({热度:.2f})")
        print(f"➡ 建议：{建议} | 把握度：{把握度:.1f}% | 风险：{风险} | 稳定度：{稳定度:.1f}% | AI信心：{AI信心:.1f}%")
        print(f"📊 修正预测：{修正预测:.4f} | 记忆权重：{AI记忆权重[s]:.2f}")
        print(f"🎯 止盈：{止盈:.2f} | ⛔ 止损：{止损:.2f}")
        print("-"*75)
        time.sleep(1)
    print("系统稳定运行中，AI记忆融合与情绪热度检测中...\n")
    time.sleep(采样间隔)