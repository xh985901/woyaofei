# 🚀《我要飞合约版》v54 多周期融合预测 + 波动权重自适应系统
# -*- coding: utf-8 -*-
import requests, time, random
from datetime import datetime
from collections import deque

# ===== 币安API =====
api_url = "https://api.binance.com/api/v3/ticker/price"
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

# ===== 参数 =====
短周期缓存 = {s: deque(maxlen=6) for s in symbols}      # 每次8秒采样 -> 约48秒窗口
中周期缓存 = {s: deque(maxlen=12) for s in symbols}     # 约1分半
采样间隔 = 8
AI权重 = {s: {"短线": 0.6, "中线": 0.4} for s in symbols}
AI信心 = {s: 100.0 for s in symbols}

def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        r = requests.get(api_url, params={"symbol": symbol}, timeout=5)
        return float(r.json()["price"])
    except:
        return None

def 计算波动序列(prices):
    if len(prices) < 2: return 0
    return (prices[-1] - prices[-2]) / prices[-2] * 100

def AI短线预测(prices):
    if len(prices) < 3: return 0
    seq = [(prices[i] - prices[i-1]) / prices[i-1] * 100 for i in range(1, len(prices))]
    return sum(seq[-3:]) / 3 + random.uniform(-0.05, 0.05)

def AI中线预测(prices):
    if len(prices) < 4: return 0
    seq = [(prices[i] - prices[i-1]) / prices[i-1] * 100 for i in range(1, len(prices))]
    平滑 = sum(seq[-4:]) / 4
    return 平滑 * random.uniform(0.9, 1.1)

def 融合预测(symbol):
    短线 = AI短线预测(短周期缓存[symbol])
    中线 = AI中线预测(中周期缓存[symbol])
    短波动 = abs(短线)
    中波动 = abs(中线)
    波动强度 = max(短波动, 中波动)

    # 动态调整权重
    if 波动强度 > 1.5:
        AI权重[symbol]["短线"] = 0.7
        AI权重[symbol]["中线"] = 0.3
    elif 波动强度 < 0.3:
        AI权重[symbol]["短线"] = 0.4
        AI权重[symbol]["中线"] = 0.6
    else:
        AI权重[symbol]["短线"] = 0.5
        AI权重[symbol]["中线"] = 0.5

    综合预测 = (短线 * AI权重[symbol]["短线"] + 中线 * AI权重[symbol]["中线"])
    return 综合预测, 波动强度

def 生成信号(symbol, 当前价):
    if len(短周期缓存[symbol]) < 3 or len(中周期缓存[symbol]) < 3:
        return None

    预测值, 波动强度 = 融合预测(symbol)
    把握度 = min(100, abs(预测值) * random.uniform(70, 130))
    风险 = "高" if 波动强度 > 1.5 else "中" if 波动强度 > 0.5 else "低"
    稳定度 = max(70, 100 - 波动强度 * 15)

    # AI信心分数更新
    AI信心[symbol] = (AI信心[symbol] * 0.9 + 稳定度 * 0.1)

    if 把握度 < 40:
        建议 = "观望"
    elif 把握度 < 70:
        建议 = "轻仓试探"
    elif 把握度 < 85:
        建议 = "中仓进场"
    else:
        建议 = "重仓信号"

    止盈 = 当前价 * (1.008 if 预测值 > 0 else 0.992)
    止损 = 当前价 * (0.992 if 预测值 > 0 else 1.008)

    return 把握度, 风险, 稳定度, 波动强度, 建议, 止盈, 止损, 预测值

# ===== 主循环 =====
print(f"{获取时间()} 🚀 启动《我要飞合约版》v54 多周期融合预测 + 波动权重自适应系统\n")

while True:
    print("="*75)
    for s in symbols:
        当前价 = 获取币价(s)
        if not 当前价:
            print(f"⚠️ {s} 数据获取失败。")
            continue

        短周期缓存[s].append(当前价)
        中周期缓存[s].append(当前价)

        信号 = 生成信号(s, 当前价)
        if not 信号:
            continue

        把握度, 风险, 稳定度, 波动强度, 建议, 止盈, 止损, 预测值 = 信号
        print(f"{获取时间()} {s} 当前价：{当前价:.2f} USDT | 波动强度：{波动强度:.2f}")
        print(f"➡ 建议：{建议} | 把握度：{把握度:.1f}% | 风险：{风险} | 稳定度：{稳定度:.1f}% | AI信心：{AI信心[s]:.1f}")
        print(f"📊 短: {AI权重[s]['短线']:.2f} | 中: {AI权重[s]['中线']:.2f} | 预测趋势: {预测值:.3f}")
        print(f"🎯 止盈：{止盈:.2f} | ⛔ 止损：{止损:.2f}")
        print("-"*75)
        time.sleep(1)
    print("系统稳定运行中，AI多周期融合预测中...\n")
    time.sleep(采样间隔)