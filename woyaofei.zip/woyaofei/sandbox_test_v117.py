# ===========================================
sandbox_test_v117.py
# ===========================================

import os
import json
import threading
from pathlib import Path
import datetime

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class AutoPosition:
    """
    实盘自动仓位管理模块：
      - 根据信号强度动态分配资金（比例动态调节）
      - 支持安全释放与异常保护
      - 自动保存账户资金状态到 JSON 文件
      - 可与真实交易逻辑无缝衔接
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("AutoPosition")
        self.lock = threading.Lock()

        # 资金状态文件路径
        data_dir = Path(self.cfg.get("data_dir"))
        data_dir.mkdir(parents=True, exist_ok=True)
        self.capital_file = data_dir / "capital_state.json"

        self.state = self._load_capital()

        self.logger.info("AutoPosition 初始化完成", {
            "balance": self.state["balance"],
            "used": self.state["used"],
            "file": str(self.capital_file)
        })

    # ---------- 文件读写 ----------
    def _load_capital(self) -> dict:
        """从 JSON 文件加载资金状态"""
        if self.capital_file.exists():
            try:
                with open(self.capital_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if "balance" in data and "used" in data:
                        return data
            except Exception as e:
                self.logger.warning(f"读取资金文件失败，将重新初始化: {e}")
        return {"balance": 10000.0, "used": 0.0}

    def _save_capital(self):
        """安全写入资金状态"""
        with self.lock:
            try:
                with open(self.capital_file, "w", encoding="utf-8") as f:
                    json.dump(self.state, f, ensure_ascii=False, indent=2)
            except Exception as e:
                self.logger.error(f"写入资金文件失败: {e}")

    # ---------- 动态分配 ----------
    def compute_position(self, signal_strength: float) -> float:
        """
        根据信号强度动态调整仓位比例
        参数:
            signal_strength : 信号强度（0~1）
        返回:
            实际分配的资金金额（USDT）
        """
        if not (0 <= signal_strength <= 1):
            self.logger.error("无效的信号强度参数，应为 0~1 之间")
            return 0.0

        with self.lock:
            base_ratio = 0.1
            max_ratio = 0.5
            position_ratio = base_ratio + (max_ratio - base_ratio) * signal_strength

            free_balance = self.state["balance"] - self.state["used"]
            if free_balance <= 0:
                self.logger.warning("⚠️ 可用资金不足，无法开仓")
                return 0.0

            alloc = free_balance * position_ratio
            alloc = round(max(0, min(alloc, free_balance)), 2)

            self.state["used"] += alloc
            self._save_capital()

            remain = round(self.state["balance"] - self.state["used"], 2)
            self.logger.info(f"📊 动态分配资金：信号强度 {signal_strength:.2f} → 分配 {alloc:.2f} USDT | 剩余 {remain:.2f} USDT")
            return alloc

    # ---------- 释放仓位 ----------
    def release_position(self, released_amount: float):
        """释放已使用的部分资金"""
        if released_amount <= 0:
            self.logger.warning("⚠️ 释放金额应大于 0")
            return

        with self.lock:
            self.state["used"] = max(0.0, self.state["used"] - released_amount)
            self._save_capital()

            remain = round(self.state["balance"] - self.state["used"], 2)
            self.logger.info(f"💰 释放资金：{released_amount:.2f} USDT | 可用余额 {remain:.2f} USDT")

    # ---------- 账户总览 ----------
    def snapshot(self) -> dict:
        """返回当前资金快照"""
        snap = {
            "balance": round(self.state["balance"], 2),
            "used": round(self.state["used"], 2),
            "available": round(self.state["balance"] - self.state["used"], 2),
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.logger.debug("账户快照", snap)
        return snap


# ---------- 独立运行 ----------
if __name__ == "__main__":
    ap = AutoPosition()
    ap.compute_position(0.2)
    ap.compute_position(0.8)
    ap.release_position(300)
    print(ap.snapshot())