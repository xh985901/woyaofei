# ===========================================
sandbox_test_v111.py
# ===========================================

import os
import threading
import datetime
import json
from pathlib import Path

try:
    # Android / BeeWare 环境可能无法直接写 C:\
    from appdirs import user_data_dir
    BASE_LOG_DIR = Path(user_data_dir("mywoyaofei", "JACK")) / "logs"
except Exception:
    # 若 appdirs 不可用则退回当前目录下
    BASE_LOG_DIR = Path(os.getcwd()) / "logs"

class GlobalLogger:
    """
    实盘版日志管理器：
      - 自动适配可写路径（支持 Android 环境）
      - 多线程安全写入
      - 自动清理旧日志（默认7天）
      - 支持多等级日志输出
    """

    def __init__(self, module_name="global", keep_days=7, level="INFO"):
        self.base_dir = BASE_LOG_DIR
        self.module_name = module_name
        self.keep_days = keep_days
        self.level = level.upper()
        self.lock = threading.Lock()
        os.makedirs(self.base_dir, exist_ok=True)

    # ---------- 内部辅助 ----------
    def _get_log_file_path(self):
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        return self.base_dir / f"{today}.log"

    def _rotate_logs(self):
        files = sorted(self.base_dir.glob("*.log"), key=lambda f: f.stat().st_mtime)
        if len(files) > self.keep_days:
            for f in files[:-self.keep_days]:
                try:
                    f.unlink()
                except Exception:
                    pass

    # ---------- 核心写入 ----------
    def log(self, level, message, data=None):
        """写入一条日志记录"""
        with self.lock:
            self._rotate_logs()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            record = {
                "time": now,
                "module": self.module_name,
                "level": level.upper(),
                "message": message
            }
            if data is not None:
                record["data"] = data

            line = json.dumps(record, ensure_ascii=False)
            path = self._get_log_file_path()
            with open(path, "a", encoding="utf-8") as f:
                f.write(line + "\n")

            # 控制台输出保留，用于调试
            print(f"[{record['time']}] {record['module']} | {record['level']}: {record['message']}")

    # ---------- 快捷方法 ----------
    def info(self, message, data=None):
        if self.level in ["INFO", "DEBUG"]:
            self.log("INFO", message, data)

    def warning(self, message, data=None):
        if self.level in ["INFO", "DEBUG", "WARNING"]:
            self.log("WARNING", message, data)

    def error(self, message, data=None):
        self.log("ERROR", message, data)

    def debug(self, message, data=None):
        if self.level == "DEBUG":
            self.log("DEBUG", message, data)

# ---------- 独立运行测试 ----------
if __name__ == "__main__":
    logger = GlobalLogger(module_name="test_logger", level="DEBUG")
    logger.info("系统启动成功")
    logger.warning("测试警告", {"key": "value"})
    logger.error("测试错误信息")
    logger.debug("调试信息")