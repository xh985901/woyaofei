# ===========================================
sandbox_test_v112.py
# ===========================================

import os
import json
import datetime
from typing import Any
from pathlib import Path

try:
    # BeeWare/Android 环境可写目录
    from appdirs import user_data_dir
    BASE_CONFIG_DIR = Path(user_data_dir("mywoyaofei", "JACK"))
except Exception:
    # 若 appdirs 不可用，退回当前工作目录
    BASE_CONFIG_DIR = Path(os.getcwd()) / "config"

DEFAULT_CONFIG = {
    "symbol": "BTCUSDT",
    "timeframe": "1h",
    "cooldown_seconds": 60,
    "log_level": "INFO",
    "report_dir": str(BASE_CONFIG_DIR / "reports"),
    "data_dir": str(BASE_CONFIG_DIR / "data"),
    "keep_logs_days": 7
}

class ConfigManager:
    """
    实盘配置管理器：
      - 自动创建默认配置文件
      - 动态适配平台路径（Android/Windows/Linux）
      - 支持读取、修改、保存、打印配置
    """

    def __init__(self, config_name="config.json", auto_create=True):
        self.config_path = BASE_CONFIG_DIR / config_name
        self.data = {}
        os.makedirs(BASE_CONFIG_DIR, exist_ok=True)

        if auto_create and not self.config_path.exists():
            self._create_default_config()
        self._load_config()

    # ---------- 内部方法 ----------
    def _create_default_config(self):
        with open(self.config_path, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, ensure_ascii=False, indent=2)

    def _load_config(self):
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                self.data = json.load(f)
        except Exception:
            # 若文件损坏，重建默认配置
            self.data = DEFAULT_CONFIG.copy()
            self._save_config()

        # 保证新字段也存在
        for k, v in DEFAULT_CONFIG.items():
            if k not in self.data:
                self.data[k] = v
        self._save_config()

    def _save_config(self):
        with open(self.config_path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    # ---------- 外部接口 ----------
    def get(self, key: str, default: Any = None) -> Any:
        """读取单项配置"""
        return self.data.get(key, default)

    def set(self, key: str, value: Any):
        """修改配置并保存"""
        self.data[key] = value
        self._save_config()

    def reload(self):
        """重新加载配置"""
        self._load_config()

    def all(self):
        """返回全部配置"""
        return self.data

    def summary(self):
        """打印当前配置（控制台或日志）"""
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{now}] 当前配置:")
        for k, v in self.data.items():
            print(f"  {k}: {v}")

# ---------- 模块独立运行 ----------
if __name__ == "__main__":
    cfg = ConfigManager()
    cfg.summary()
    cfg.set("symbol", "ETHUSDT")
    cfg.set("cooldown_seconds", 120)
    print("\n修改后的配置:")
    cfg.summary()