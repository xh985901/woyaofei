# ===========================================
sandbox_test_v114.py
# ===========================================

import os
import json
import datetime
from pathlib import Path
from typing import Optional, Dict, Any

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class StepTPSL:
    """
    实盘止盈止损模块（Step Take-Profit / Stop-Loss）
      - 分级止盈：多档次止盈自动触发（默认 1%、3%、5%）
      - 动态止损：盈亏回撤触发止损（默认 -2%）
      - 自动记录每次交易事件到 JSON 文件
      - 日志输出可用于策略回测或实盘监控
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("StepTPSL")

        # 止盈止损参数（可在配置中自定义）
        self.take_profit_levels = [0.01, 0.03, 0.05]  # 1%、3%、5%
        self.stop_loss_level = -0.02  # -2%

        # 使用动态可写路径
        data_dir = Path(self.cfg.get("data_dir"))
        data_dir.mkdir(parents=True, exist_ok=True)
        self.data_path = data_dir / "tp_sl_records.json"

        # 加载已有记录
        self.records = self._load_records()

        self.logger.info("StepTPSL 初始化成功", {
            "take_profit_levels": self.take_profit_levels,
            "stop_loss_level": self.stop_loss_level,
            "record_file": str(self.data_path)
        })

    # ---------- 内部函数 ----------
    def _load_records(self) -> list:
        """从 JSON 文件加载历史止盈止损记录"""
        if self.data_path.exists():
            try:
                with open(self.data_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                self.logger.warning(f"记录文件读取失败，将重新创建: {e}")
        return []

    def _save_records(self):
        """保存止盈止损记录"""
        try:
            with open(self.data_path, "w", encoding="utf-8") as f:
                json.dump(self.records, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.logger.error(f"保存记录失败: {e}")

    # ---------- 主逻辑 ----------
    def evaluate_position(self, entry_price: float, current_price: float, qty: float = 1.0) -> Optional[Dict[str, Any]]:
        """
        检查是否触发止盈或止损。
        参数：
            entry_price : 开仓价格
            current_price : 当前价格
            qty : 仓位数量
        返回：
            若触发止盈或止损，返回记录字典，否则返回 None
        """
        if entry_price <= 0 or current_price <= 0:
            self.logger.error("无效价格参数")
            return None

        pnl_ratio = (current_price - entry_price) / entry_price
        pnl_value = pnl_ratio * 100
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # ---------- 止盈检测 ----------
        for level in sorted(self.take_profit_levels):
            if pnl_ratio >= level:
                record = {
                    "time": now,
                    "type": f"止盈 {int(level * 100)}%",
                    "entry_price": entry_price,
                    "exit_price": current_price,
                    "profit_ratio": round(pnl_ratio, 4),
                    "qty": qty
                }
                self.records.append(record)
                self._save_records()
                self.logger.info(f"✅ 触发分级止盈 {int(level * 100)}% ，盈利 {pnl_value:.2f}%")
                return record

        # ---------- 止损检测 ----------
        if pnl_ratio <= self.stop_loss_level:
            record = {
                "time": now,
                "type": f"止损 {int(abs(self.stop_loss_level) * 100)}%",
                "entry_price": entry_price,
                "exit_price": current_price,
                "profit_ratio": round(pnl_ratio, 4),
                "qty": qty
            }
            self.records.append(record)
            self._save_records()
            self.logger.warning(f"⚠️ 触发止损 {int(abs(self.stop_loss_level) * 100)}%，亏损 {pnl_value:.2f}%")
            return record

        # ---------- 未触发 ----------
        self.logger.info(f"持仓中：浮动盈亏 {pnl_value:.2f}%")
        return None


# ---------- 独立测试 ----------
if __name__ == "__main__":
    tp = StepTPSL()
    entry = 100.0
    test_prices = [101.5, 103.0, 98.0, 105.5, 99.0]
    for price in test_prices:
        tp.evaluate_position(entry, price, qty=1)