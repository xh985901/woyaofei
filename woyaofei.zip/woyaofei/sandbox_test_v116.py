# ===========================================
sandbox_test_v116.py
# ===========================================

import os
import time
import datetime
from pathlib import Path

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")  # ✅ 使用无界面后端，防止 Android 崩溃
import matplotlib.pyplot as plt

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager


class VisualDashboard:
    """
    实盘可视化模块（后台生成图像文件）
      - 自动从 CSV 读取实时行情数据
      - 生成买卖盘比 + 价格趋势图
      - 每隔 N 秒刷新保存 PNG 文件（供前端展示）
    """

    def __init__(self, refresh_interval=5):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("VisualDashboard")

        # 数据与输出路径
        data_dir = Path(self.cfg.get("data_dir"))
        report_dir = Path(self.cfg.get("report_dir")) / "visuals"
        report_dir.mkdir(parents=True, exist_ok=True)

        self.data_path = data_dir / "realtime_feed.csv"
        self.chart_path = report_dir / "dashboard_latest.png"

        self.refresh_interval = refresh_interval
        self.logger.info("VisualDashboard 初始化成功", {
            "data_path": str(self.data_path),
            "chart_output": str(self.chart_path),
            "refresh_interval": self.refresh_interval
        })

    # ---------- 数据加载 ----------
    def load_latest_data(self) -> pd.DataFrame | None:
        """加载最新实时行情数据"""
        if not self.data_path.exists():
            self.logger.warning("⚠️ 找不到实时数据文件")
            return None

        try:
            df = pd.read_csv(self.data_path)
            # 检查必须列
            for col in ["time", "buy_ratio", "sell_ratio", "price"]:
                if col not in df.columns:
                    raise ValueError(f"缺少列: {col}")
            return df.tail(50)  # 保留最近 50 条
        except Exception as e:
            self.logger.error(f"❌ 数据读取失败: {e}")
            return None

    # ---------- 图表更新 ----------
    def update_chart(self):
        """刷新并保存图像文件"""
        df = self.load_latest_data()
        if df is None or len(df) < 5:
            return

        try:
            t = df["time"]
            buy = df["buy_ratio"]
            sell = df["sell_ratio"]
            price = df["price"]

            plt.figure(figsize=(9, 6))
            plt.suptitle("《我要飞·实盘监控面板》", fontsize=12)

            # 价格趋势
            plt.subplot(2, 1, 1)
            plt.plot(t, price, color="orange", linewidth=1.5, label="价格趋势")
            plt.title("价格趋势图")
            plt.grid(True)
            plt.legend()

            # 买卖盘比
            plt.subplot(2, 1, 2)
            plt.plot(t, buy, color="green", label="买盘比例")
            plt.plot(t, sell, color="red", label="卖盘比例")
            plt.title("买卖盘比变化")
            plt.grid(True)
            plt.legend()

            plt.tight_layout()
            plt.savefig(self.chart_path, dpi=150)
            plt.close()
            self.logger.info(f"✅ 可视化图已更新: {self.chart_path}")
        except Exception as e:
            self.logger.error(f"绘图失败: {e}")

    # ---------- 主循环 ----------
    def run(self):
        """后台循环更新图像文件（适合实盘或 APK 内后台任务）"""
        self.logger.info("开始运行实时可视化后台任务...")
        while True:
            self.update_chart()
            time.sleep(self.refresh_interval)


# ---------- 独立运行 ----------
if __name__ == "__main__":
    dash = VisualDashboard(refresh_interval=5)
    dash.run()