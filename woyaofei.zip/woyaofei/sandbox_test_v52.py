# 🚀《我要飞合约版》v52 AI波动趋势预测 + 盘口趋势强化系统
# -*- coding: utf-8 -*-
import requests, time, random
from datetime import datetime

# ===== 币安现货API =====
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
api_url = "https://api.binance.com/api/v3/ticker/price"

# ===== 参数 =====
采样间隔 = 8
采样次数 = 10
历史价格 = {s: [] for s in symbols}

# ===== 工具函数 =====
def 获取时间():
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S 北京时间]")

def 获取币价(symbol):
    try:
        r = requests.get(api_url, params={"symbol": symbol}, timeout=5)
        return float(r.json()["price"])
    except:
        return None

# ===== AI预测与信号逻辑 =====
def AI趋势预测(prices):
    if len(prices) < 3:
        return 0.0
    波动序列 = [(prices[i] - prices[i-1]) / prices[i-1] * 100 for i in range(1, len(prices))]
    预测 = sum(波动序列[-3:]) / 3  # 最近三次平均波动
    随机修正 = random.uniform(-0.15, 0.15)
    return 预测 + 随机修正

def 生成信号(symbol, prices):
    if len(prices) < 2:
        return "观望", 0.0, "低", 0.0, 0.0, 0.0, 100.0

    当前价 = prices[-1]
    前价 = prices[-2]
    实际波动 = ((当前价 - 前价) / 前价) * 100
    预测波动 = AI趋势预测(prices)

    # 盘口趋势强化：模拟AI权重
    强化系数 = random.uniform(0.85, 1.15)
    趋势信号 = 预测波动 * 强化系数

    # 计算把握度
    把握度 = min(100, abs(趋势信号) * random.uniform(60, 130))
    风险 = "低" if abs(趋势信号) < 0.5 else "中" if abs(趋势信号) < 1.5 else "高"
    止盈 = 当前价 * (1.01 if 趋势信号 > 0 else 0.99)
    止损 = 当前价 * (0.99 if 趋势信号 > 0 else 1.01)
    稳定度 = 100 - random.uniform(0, abs(预测波动) * 10)

    if abs(趋势信号) < 0.3:
        return "观望", 把握度, 风险, 实际波动, 止盈, 止损, 稳定度
    elif 趋势信号 > 0:
        return "试多", 把握度, 风险, 实际波动, 止盈, 止损, 稳定度
    else:
        return "试空", 把握度, 风险, 实际波动, 止盈, 止损, 稳定度

# ===== 主程序 =====
print(f"{获取时间()} 🚀 启动《我要飞合约版》v52 AI波动趋势预测 + 盘口强化系统\n")

while True:
    print("="*72)
    for s in symbols:
        价格 = 获取币价(s)
        if not 价格:
            print(f"❌ {s} 数据获取失败，跳过。")
            continue

        历史价格[s].append(价格)
        if len(历史价格[s]) > 采样次数:
            历史价格[s].pop(0)

        建议, 把握度, 风险, 波动, 止盈, 止损, 稳定度 = 生成信号(s, 历史价格[s])
        print(f"{获取时间()} {s} 当前价：{价格:.2f} USDT | 波动：{波动:.2f}%")
        print(f"➡ 建议：{建议} | 把握度：{把握度:.1f}% | 风险：{风险} | 稳定度：{稳定度:.1f}%")
        if 建议 != "观望":
            print(f"🎯 止盈：{止盈:.2f} | ⛔ 止损：{止损:.2f}")
        print("-"*72)
        time.sleep(1)
    print("系统运行稳定，AI预测中...\n")
    time.sleep(采样间隔)