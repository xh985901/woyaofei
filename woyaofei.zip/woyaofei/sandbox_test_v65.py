# 🚀《我要飞合约版》v65 AI信号冷却优化 + 主趋势确认系统
# Author: JACK & GPT-5 | 更新时间：2025-10-06 01:18 北京时间

import time, random, datetime

coins = [
    {"name": "BTCUSDT", "price": 123000.0},
    {"name": "ETHUSDT", "price": 4500.0},
    {"name": "SOLUSDT", "price": 230.0}
]

price_history = {c["name"]: [c["price"]] for c in coins}
cooldown_status = {c["name"]: 0 for c in coins}

def detect_trend(prices):
    if len(prices) < 5: return 0
    diff = prices[-1] - prices[0]
    avg = sum(prices) / len(prices)
    trend = diff / avg * 100
    return round(trend, 2)

def gen_short_signal():
    return round(random.uniform(-2.5, 2.5), 2)

def run_v65():
    print(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 北京时间] 🚀 启动《我要飞合约版》v65 AI信号冷却优化 + 主趋势确认系统")
    print("="*78)
    while True:
        for c in coins:
            new_price = round(c["price"] + random.uniform(-80, 80), 2)
            price_history[c["name"]].append(new_price)
            if len(price_history[c["name"]]) > 15:
                price_history[c["name"]].pop(0)

            trend_score = detect_trend(price_history[c["name"]])
            short_signal = gen_short_signal()
            consistent = "✅ 一致" if (trend_score * short_signal) > 0 else "⚠️ 反向"
            trend_state = "📈 上升" if trend_score > 0.3 else "📉 下降" if trend_score < -0.3 else "⏸ 震荡"
            
            cooldown = cooldown_status[c["name"]]
            if abs(trend_score) < 0.3:
                cooldown_status[c["name"]] = min(3, cooldown + 1)
                advice = "⏳ 观望（主趋势未定）"
            elif consistent == "✅ 一致":
                cooldown_status[c["name"]] = 0
                advice = "🟢 可轻仓跟随"
            else:
                cooldown_status[c["name"]] = 2
                advice = "🚫 信号冲突，冷却中"

            print(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 北京时间] {c['name']} 当前价：{new_price} USDT")
            print(f"主趋势：{trend_state}({trend_score:+.2f}%) | 短时信号：{short_signal:+.2f}% | 一致性：{consistent}")
            print(f"冷却状态：{cooldown_status[c['name']]} | 建议：{advice}")
            print("-"*70)
        print("系统运行稳定，AI趋势确认中...\n")
        time.sleep(5)

if __name__ == "__main__":
    run_v65()