"""
《我要飞合约版》v10 实盘沙盒整合源码 - 第二段
模块范围：#6 ~ #11
功能：止盈止损、智能区间止盈止损、自动加减仓、高倍速决策、模拟账户、盈亏显示
"""

import time, random
from datetime import datetime
import pytz

def log(msg):
    now = datetime.now(pytz.timezone("Asia/Shanghai")).strftime("[%Y-%m-%d %H:%M:%S]")
    print(f"{now} {msg}")

# =============== 模块06：阶梯止盈止损 ===============
class StepTP_SL:
    """多档止盈止损"""
    def __init__(self, tp_levels=[0.02, 0.04, 0.06], sl_levels=[-0.01, -0.02, -0.03]):
        self.tp_levels = tp_levels
        self.sl_levels = sl_levels
        self.executed = set()

    def check(self, profit_rate):
        for tp in self.tp_levels:
            if profit_rate >= tp and tp not in self.executed:
                log(f"🎯 触发止盈 {tp*100:.1f}%")
                self.executed.add(tp)
        for sl in self.sl_levels:
            if profit_rate <= sl and sl not in self.executed:
                log(f"⚠️ 触发止损 {sl*100:.1f}%")
                self.executed.add(sl)

# =============== 模块07：智能区间止损 + 假突破过滤 ===============
class SmartRangeProtect:
    def __init__(self):
        self.active_zone = None

    def update_zone(self, price):
        atr = random.uniform(50, 200)
        self.active_zone = (price - atr, price + atr)

    def check_break(self, price):
        if not self.active_zone: return
        low, high = self.active_zone
        if price < low:
            log("⚠️ 价格跌破防护区间，下调仓位")
        elif price > high:
            log("✅ 价格突破上沿，趋势延续")

# =============== 模块08：高倍速战速决交易模式 ===============
class FastDecisionMode:
    """一键进出场（每日一次）"""
    def __init__(self):
        self.active = False

    def trigger(self):
        self.active = True
        log("🚀 启动战速决交易模式")

    def execute_trade(self, side="BUY"):
        if not self.active:
            log("⚠️ 战速决模式未激活")
            return
        log(f"⚡ 执行快速下单：{side}")
        self.active = False

# =============== 模块09：自动加减仓/倍数调整 ===============
class AutoPositionAdjust:
    """根据胜率动态调整仓位"""
    def __init__(self, base_size=1.0):
        self.base_size = base_size

    def adjust(self, winrate):
        if winrate >= 0.8:
            size = self.base_size * 2
        elif winrate >= 0.7:
            size = self.base_size * 1.5
        else:
            size = self.base_size * 1.0
        log(f"📈 调整仓位倍数：{size:.1f}x（胜率 {winrate*100:.1f}%）")
        return size

# =============== 模块10：模拟测试（假资金账户） ===============
class SimAccount:
    """用于沙盒模拟盈亏"""
    def __init__(self, balance=10000):
        self.balance = balance
        self.equity_log = []

    def trade(self, pnl):
        self.balance += pnl
        self.equity_log.append(self.balance)
        log(f"💰 模拟账户更新：当前余额 {self.balance:.2f} USDT")

    def summary(self):
        if not self.equity_log:
            log("暂无交易记录")
            return
        min_eq = min(self.equity_log)
        max_eq = max(self.equity_log)
        log(f"📊 盈亏区间：最低 {min_eq:.2f} → 最高 {max_eq:.2f}")

# =============== 模块11：盈亏金额显示 ===============
class PnLDisplay:
    """读取模拟账户数据展示盈亏"""
    def __init__(self, account: SimAccount):
        self.acc = account

    def show(self):
        if not self.acc.equity_log:
            log("⚠️ 暂无盈亏记录")
            return
        last = self.acc.equity_log[-1]
        first = self.acc.equity_log[0]
        change = (last - first) / first * 100
        log(f"📈 累计收益率：{change:.2f}%")

# =============== 第二阶段沙盒测试入口 ===============
if __name__ == "__main__":
    log("🚀 启动策略与风控沙盒测试（模块6~11）")
    tp_sl = StepTP_SL()
    protect = SmartRangeProtect()
    mode = FastDecisionMode()
    adj = AutoPositionAdjust()
    acc = SimAccount()
    pnlshow = PnLDisplay(acc)

    mode.trigger()
    for i in range(5):
        pr = random.uniform(-0.05, 0.07)
        tp_sl.check(pr)
        protect.update_zone(60000 + i*100)
        protect.check_break(60000 + i*150)
        adj.adjust(random.uniform(0.6, 0.9))
        acc.trade(random.uniform(-100, 300))
        time.sleep(1)

    pnlshow.show()
    log("✅ 模块6~11 沙盒测试完成")