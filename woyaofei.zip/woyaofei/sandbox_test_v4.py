# ======================================================
# 模块12: 时间同步与保护 (TimeSyncProtect)
# 功能: 校准本地时间与交易所serverTime, 超差则熔断。
# ======================================================

import time
import requests
import random
import hashlib
import datetime


class TimeSyncProtect:
    def __init__(self, api_url="https://api.binance.com/api/v3/time", max_diff_ms=1500):
        self.api_url = api_url
        self.max_diff_ms = max_diff_ms
        self.offset = 0
        self.last_check = 0

    def sync_time(self):
        try:
            resp = requests.get(self.api_url, timeout=3)
            server_time = resp.json()["serverTime"]
            local_time = int(time.time() * 1000)
            self.offset = server_time - local_time
            self.last_check = time.time()
            print(f"🕒 同步时间完成, 偏差 {self.offset} ms")
        except Exception as e:
            print(f"⚠️ 时间同步失败: {e}")

    def is_time_safe(self):
        """判断时间偏差是否在安全范围"""
        if abs(self.offset) > self.max_diff_ms:
            print("❌ 时间偏差过大, 熔断系统进入只读模式")
            return False
        return True


# ======================================================
# 模块13: 网络与下单保护 (NetworkOrderProtect)
# 功能: 监控延迟与丢包, 自动触发熔断暂停下单。
# ======================================================

class NetworkOrderProtect:
    def __init__(self, latency_threshold_ms=500, packet_loss_threshold=0.2):
        self.latency_threshold_ms = latency_threshold_ms
        self.packet_loss_threshold = packet_loss_threshold
        self.network_ok = True

    def check_latency(self):
        """模拟延迟检测"""
        latency = random.randint(50, 800)
        if latency > self.latency_threshold_ms:
            print(f"⚠️ 网络延迟 {latency}ms 超阈值, 暂停下单")
            self.network_ok = False
        else:
            self.network_ok = True
        return latency

    def check_packet_loss(self):
        """模拟丢包检测"""
        loss_rate = random.random() * 0.3
        if loss_rate > self.packet_loss_threshold:
            print(f"❌ 丢包率 {loss_rate*100:.1f}% 超阈值")
            self.network_ok = False
        return loss_rate

    def can_place_order(self):
        """判断是否允许下单"""
        return self.network_ok


# ======================================================
# 模块14: 一键租用服务器 (ServerRental)
# 功能: 预留远程服务器连接占位, 不启用真实交易，仅作配置。
# ======================================================

class ServerRental:
    def __init__(self):
        self.server_region = "Asia"
        self.status = "OFF"

    def rent_server(self, region="Asia"):
        self.server_region = region
        self.status = "ACTIVE"
        print(f"🛰️ 已租用服务器节点: {region}")

    def stop_server(self):
        self.status = "OFF"
        print("🛑 服务器已关闭。")

    def check_status(self):
        print(f"🌐 当前服务器状态: {self.status}")


# ======================================================
# 模块15: 安全控制 (SecurityControl)
# 功能: 禁止提现、下单需确认、日志记录。
# ======================================================

class SecurityControl:
    def __init__(self, allow_withdraw=False, require_confirm=True):
        self.allow_withdraw = allow_withdraw
        self.require_confirm = require_confirm
        self.logs = []

    def confirm_action(self, action_desc):
        """操作确认"""
        if self.require_confirm:
            confirm = input(f"⚠️ 请确认操作: {action_desc} (y/n): ")
            return confirm.lower() == "y"
        return True

    def withdraw_funds(self, amount):
        """禁止提现"""
        if not self.allow_withdraw:
            print("❌ 提现被禁止! 安全策略已启用。")
            return False
        print(f"💸 已提现 {amount}")
        return True

    def log_action(self, action, detail=""):
        """操作记录与签名"""
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = f"[{ts}] {action} - {detail}"
        sign = hashlib.sha256(record.encode()).hexdigest()[:10]
        self.logs.append((record, sign))
        print(f"📜 {record} | 签名: {sign}")

    def show_logs(self):
        """打印日志"""
        print("📋 安全日志记录:")
        for rec, sign in self.logs:
            print(f"{rec} | {sign}")


# ======================================================
# ✅ 主程序测试入口
# ======================================================

if __name__ == "__main__":
    print("🚀 模块12~15 综合测试开始...\n")

    # 时间同步测试
    t = TimeSyncProtect()
    t.sync_time()
    t.is_time_safe()

    # 网络保护测试
    n = NetworkOrderProtect()
    n.check_latency()
    n.check_packet_loss()
    print(f"✅ 网络状态允许下单: {n.can_place_order()}")

    # 服务器租用测试
    s = ServerRental()
    s.rent_server("Singapore")
    s.check_status()
    s.stop_server()
    s.check_status()

    # 安全控制测试
    sec = SecurityControl(allow_withdraw=False, require_confirm=False)
    sec.withdraw_funds(100)
    sec.log_action("TestAction", "模块15测试")
    sec.show_logs()

    print("\n🎯 全部模块测试完毕。")