# v87 AI决策权重自学习系统 + 仓位映射进化模块
import random, time

# 初始化权重（趋势、情绪、量能、波动）
weights = {"trend": 0.25, "emotion": 0.25, "volume": 0.25, "volatility": 0.25}

# 模拟AI的学习记录
performance_memory = []

def ai_self_learning(symbol, price, success_rate, last_action):
    print(f"\n🚀 启动《我要飞合约版》v87 模块：AI权重自学习系统 + 仓位映射进化模块")
    print("=" * 60)
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')} 北京时间] {symbol} 当前价：{price} USDT")

    # 记录历史表现
    performance_memory.append(success_rate)
    avg_perf = sum(performance_memory[-5:]) / min(5, len(performance_memory))

    # 权重动态调整逻辑
    for k in weights:
        adjust = random.uniform(-0.03, 0.03) * (1 if success_rate > avg_perf else -1)
        weights[k] = max(0.1, min(0.4, weights[k] + adjust))
    norm_factor = sum(weights.values())
    for k in weights:
        weights[k] /= norm_factor

    # 仓位映射优化
    confidence = round((success_rate * 0.7 + avg_perf * 0.3) * 100, 2)
    position_adj = round((confidence - 85) / 5, 2)  # 超过85信心才进攻
    position_adj = max(-20, min(25, position_adj))

    # 输出状态
    print(f"📈 成功率：{success_rate*100:.2f}% | 历史均值：{avg_perf*100:.2f}%")
    print(f"🧠 当前权重：{', '.join([f'{k}:{v:.2f}' for k,v in weights.items()])}")
    print(f"⚙️ 仓位映射调整：{position_adj:+.2f}% | AI综合置信：{confidence:.2f}%")
    print(f"💡 建议：{'维持当前仓位' if abs(position_adj)<5 else ('逐步加仓' if position_adj>0 else '逐步减仓')}")
    print("-" * 60)
    print("系统稳定运行中，AI权重学习与仓位进化中...\n")

# 示例运行
ai_self_learning("BTCUSDT", 123045.12, success_rate=0.91, last_action="加仓")
ai_self_learning("ETHUSDT", 4514.08, success_rate=0.87, last_action="持仓")
ai_self_learning("SOLUSDT", 248.66, success_rate=0.79, last_action="减仓")