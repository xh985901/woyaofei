# ===============================================
# 模块01：行情拉取与监控（MarketMonitor）
# 功能：从币安合约USDT对实时获取K线、成交量、深度数据。
# ===============================================

import requests, time, threading, json, websocket

class MarketMonitor:
    def __init__(self, symbol="BTCUSDT"):
        self.symbol = symbol
        self.kline_data = []
        self.depth_data = None
        self.ws = None

    def fetch_kline(self, interval="1m", limit=100):
        """通过 REST 获取历史K线"""
        url = f"https://fapi.binance.com/fapi/v1/klines?symbol={self.symbol}&interval={interval}&limit={limit}"
        res = requests.get(url, timeout=2)
        self.kline_data = res.json()
        return self.kline_data

    def start_ws(self):
        """启动实时行情 WebSocket"""
        stream = f"wss://fstream.binance.com/ws/{self.symbol.lower()}@kline_1m"
        self.ws = websocket.WebSocketApp(stream, on_message=self.on_message)
        threading.Thread(target=self.ws.run_forever, daemon=True).start()

    def on_message(self, ws, msg):
        """收到实时K线推送"""
        data = json.loads(msg)
        kline = data["k"]
        self.kline_data.append(kline)
        if len(self.kline_data) > 200:
            self.kline_data.pop(0)

    def get_latest_price(self):
        """返回最新收盘价"""
        if not self.kline_data:
            return None
        return float(self.kline_data[-1]["c"])


# ===============================================
# 模块02：异动捕捉（VolatilityDetector）
# 功能：检测未来30–45分钟可能波动≥1.5%的行情并提前预警。
# ===============================================

import numpy as np

class VolatilityDetector:
    def __init__(self, window=45, threshold=0.015):
        self.window = window
        self.threshold = threshold

    def detect(self, price_series):
        """输入价格序列，输出是否存在异动"""
        if len(price_series) < 2:
            return False, 0.0
        returns = np.diff(price_series) / price_series[:-1]
        predicted_move = np.std(returns[-self.window:]) * np.sqrt(self.window)
        return predicted_move >= self.threshold, predicted_move

    def early_warning(self, predicted_move):
        """打印预警信息"""
        if predicted_move >= self.threshold:
            print(f"⚠️ 检测到未来{self.window}分钟内可能波动 {predicted_move*100:.2f}%，提前预警！")


# ===============================================
# 模块03：盘口诱单检测（OrderbookTrapDetector）
# 功能：识别盘口中诱多/诱空挂单行为。
# ===============================================

class OrderbookTrapDetector:
    def __init__(self):
        self.trap_threshold = 0.3  # 假挂单占比阈值

    def analyze_orderbook(self, bids, asks):
        """输入买卖盘数据（前20档），返回是否疑似诱单"""
        total_bids = sum([b[1] for b in bids])
        total_asks = sum([a[1] for a in asks])
        diff = abs(total_bids - total_asks) / (total_bids + total_asks)
        if diff > self.trap_threshold:
            side = "买盘诱空" if total_bids > total_asks else "卖盘诱多"
            print(f"⚠️ 检测到疑似{side}行为（盘口差异 {diff*100:.2f}%）")
            return True, side
        return False, None


# ===============================================
# 模块04：关键位 + 量能提醒（KeyLevelVolumeAlert）
# 功能：价格接近关键价位并伴随成交量放大时提醒。
# ===============================================

class KeyLevelVolumeAlert:
    def __init__(self, level_threshold=0.005, volume_multiplier=1.5):
        self.level_threshold = level_threshold
        self.volume_multiplier = volume_multiplier
        self.key_levels = []  # 关键价位列表

    def add_key_level(self, price):
        """新增关键价位"""
        self.key_levels.append(price)

    def check(self, current_price, current_volume, avg_volume):
        """检测价格接近关键位并放量"""
        for level in self.key_levels:
            if abs(current_price - level) / level <= self.level_threshold:
                if current_volume >= avg_volume * self.volume_multiplier:
                    print(f"🔔 关键位 {level} 附近放量，当前成交量为均量 {current_volume/avg_volume:.2f}倍！")
                    return True
        return False


# ===============================================
# 模块05：流动性过滤器（LiquidityFilter）
# 功能：过滤成交额/深度不足的币种。
# ===============================================

class LiquidityFilter:
    def __init__(self, min_volume_usdt=5_000_000, min_depth_usdt=100_000):
        self.min_volume_usdt = min_volume_usdt
        self.min_depth_usdt = min_depth_usdt

    def pass_liquidity(self, symbol_info):
        """检查币种的流动性是否合格"""
        vol_ok = symbol_info["quoteVolume"] >= self.min_volume_usdt
        depth_ok = symbol_info["bidDepth"] >= self.min_depth_usdt and symbol_info["askDepth"] >= self.min_depth_usdt
        if vol_ok and depth_ok:
            return True
        else:
            print(f"❌ {symbol_info['symbol']} 流动性不足：成交额或深度不达标")
            return False
if __name__ == "__main__":
    monitor = MarketMonitor()
    data = monitor.fetch_kline()
    print("✅ 模块02 测试完成，成功拉取K线数据数量：", len(data))