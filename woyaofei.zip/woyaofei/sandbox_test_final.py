# =========================================================
# 《我要飞合约版》 vFinal_build_20251006_stable
# 作者：JACK & ChatGPT
# 模式：单轮检测 → 自动保存报告 → 稳定退出
# =========================================================

import requests
import time
import datetime
import os

COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
API_URL = "https://api.binance.com/api/v3/ticker/price?symbol={}"

def fetch_price(symbol):
    try:
        r = requests.get(API_URL.format(symbol), timeout=5)
        data = r.json()
        return float(data["price"])
    except Exception as e:
        return None

def main():
    print("="*65)
    print(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S 北京时间')}] 🚀 启动《我要飞合约版》vFinal 单轮检测模式")
    print("="*65)

    results = []
    start_time = time.time()

    for coin in COINS:
        price = fetch_price(coin)
        delay = round((time.time() - start_time) * 1000, 2)
        if price:
            print(f"📊 {coin:<8} 当前价：{price:<10} USDT | 延迟：{delay} ms ✅")
            results.append((coin, price, delay))
        else:
            print(f"⚠️ {coin:<8} 数据获取失败 ❌")
        time.sleep(1)

    print("\n🎯 检测完成（单轮模式）。系统稳定退出。")

    # 保存报告文件
    report_name = f"report_vFinal_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    report_dir = "/storage/emulated/0/Download/我要飞报告"
    os.makedirs(report_dir, exist_ok=True)
    report_path = os.path.join(report_dir, report_name)

    with open(report_path, "w", encoding="utf-8") as f:
        f.write("=== 我要飞合约版 单轮检测报告 ===\n")
        f.write(f"检测时间（北京时间）：{datetime.datetime.now()}\n\n")
        for c, p, d in results:
            f.write(f"{c:<8} 价格：{p:<10} USDT | 延迟：{d} ms\n")
        f.write("\n系统稳定退出，检测完毕。\n")

    print(f"📁 报告已保存至：{report_path}")
    print("="*65)
    print("[Program finished]")

if __name__ == "__main__":
    main()