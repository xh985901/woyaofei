# ===========================================
sandbox_test_v113.py
# ===========================================

import os
import time
import json
import datetime
from typing import Any, Dict
from threading import Lock
from pathlib import Path

from mywoyaofei.modules.module_logger_plus_real import GlobalLogger
from mywoyaofei.modules.config_manager_real import ConfigManager

class OrderFilter:
    """
    实盘信号过滤器：
      - 控制信号冷却周期（防止重复触发）
      - 检查信号变化幅度（小变化忽略）
      - 自动保存状态文件
      - 线程安全，可并发调用
    """

    def __init__(self):
        self.cfg = ConfigManager()
        self.logger = GlobalLogger("OrderFilter")
        self.lock = Lock()

        # 获取可写数据目录（自动兼容 Android）
        data_dir = Path(self.cfg.get("data_dir"))
        data_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = data_dir / "order_filter_state.json"

        # 加载或初始化状态
        self.state = self._load_state()

        # 从配置加载参数
        self.cooldown = int(self.cfg.get("cooldown_seconds", 60))  # 冷却周期
        self.signal_threshold = 0.05  # 信号变化最小差异阈值

        self.logger.info("OrderFilter 初始化完成", {
            "cooldown_seconds": self.cooldown,
            "signal_threshold": self.signal_threshold
        })

    # ---------- 状态管理 ----------
    def _load_state(self) -> Dict[str, Any]:
        """读取上次信号状态"""
        if self.state_path.exists():
            try:
                with open(self.state_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                self.logger.warning(f"状态文件读取失败：{e}")
        return {"last_signal": None, "last_time": 0}

    def _save_state(self):
        """保存当前信号状态"""
        try:
            with open(self.state_path, "w", encoding="utf-8") as f:
                json.dump(self.state, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.logger.error(f"状态保存失败：{e}")

    # ---------- 主逻辑 ----------
    def can_emit_signal(self, new_signal_value: float) -> bool:
        """
        判断是否允许发出新交易信号：
          - 若冷却期未过 → 拒绝
          - 若信号变化小于阈值 → 拒绝
          - 否则 → 更新状态并允许发出
        """
        with self.lock:
            now = time.time()
            last_signal = self.state.get("last_signal")
            last_time = self.state.get("last_time", 0)

            time_passed = now - last_time
            diff = abs(new_signal_value - (last_signal or 0))

            # 冷却检测
            if time_passed < self.cooldown:
                remaining = int(self.cooldown - time_passed)
                self.logger.info(f"冷却中：需等待 {remaining} 秒后才能发出新信号")
                return False

            # 信号变化检测
            if last_signal is not None and diff < self.signal_threshold:
                self.logger.info(f"信号变化过小 ({diff:.3f})，忽略重复信号")
                return False

            # 更新状态并写入文件
            self.state["last_signal"] = new_signal_value
            self.state["last_time"] = now
            self._save_state()

            self.logger.info(f"✅ 新信号触发: {new_signal_value:.4f}")
            return True

# ---------- 模块独立运行测试 ----------
if __name__ == "__main__":
    f = OrderFilter()
    test_signals = [0.1, 0.12, 0.2, 0.25, 0.23]
    for s in test_signals:
        result = f.can_emit_signal(s)
        print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] 信号 {s} -> {result}")
        time.sleep(2)