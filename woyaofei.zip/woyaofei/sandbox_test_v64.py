# 🚀《我要飞合约版》v64 AI信号追踪矩阵 + 动态信号衰减控制系统
# Author: JACK & GPT-5 | 更新时间：2025-10-06 01:15 北京时间

import time, random, datetime

coins = [
    {"name": "BTCUSDT", "price": 123000.0},
    {"name": "ETHUSDT", "price": 4500.0},
    {"name": "SOLUSDT", "price": 230.0}
]

signal_cache = {}
cooldown = {}

def gen_signal():
    base = random.uniform(40, 100)
    decay = random.uniform(5, 20)
    return round(base, 2), round(decay, 2)

def update_signal(name):
    now = time.time()
    last = cooldown.get(name, 0)
    if now - last < 30:
        return "🕐 冷却中", 0, 0, "等待下一轮"
    score, decay = gen_signal()
    if name not in signal_cache:
        signal_cache[name] = [score]
    else:
        signal_cache[name].append(score)
        if len(signal_cache[name]) > 3:
            signal_cache[name].pop(0)
    cooldown[name] = now
    avg = sum(signal_cache[name]) / len(signal_cache[name])
    new_score = max(0, avg - decay)
    state = "⚡ 活跃信号" if avg > 70 else "🌙 衰减中" if avg > 40 else "💤 已消退"
    advice = "可轻仓试探" if avg > 70 else "等待回暖" if avg > 40 else "保持观望"
    return state, avg, decay, advice

def run_v64():
    print(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 北京时间] 🚀 启动《我要飞合约版》v64 AI信号追踪矩阵 + 动态信号衰减控制系统")
    print("="*78)
    while True:
        for c in coins:
            state, avg, decay, advice = update_signal(c["name"])
            price = round(c["price"] + random.uniform(-50, 50), 2)
            print(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 北京时间] {c['name']} 当前价：{price} USDT")
            print(f"🔥 信号热度：{avg:.2f} | 衰减速率：{decay:.2f}% | 状态：{state}")
            print(f"💡 建议：{advice}")
            print("-"*70)
        print("系统运行稳定，AI信号矩阵追踪中...\n")
        time.sleep(5)

if __name__ == "__main__":
    run_v64()